package main

import (
	"context"
	"net"
	"strings"
	"time"
)

type NetworkResult struct {
	Ran, DNSOK, TCPOK    bool
	DNSMillis, TCPMillis int64
	DNSReason, TCPReason string
	Adapter, LocalIP     string
}

func localAdapter() (string, string) {
	ifs, e := net.Interfaces()
	if e != nil {
		return "Unavailable", ""
	}
	for _, it := range ifs {
		if it.Flags&net.FlagUp == 0 || it.Flags&net.FlagLoopback != 0 {
			continue
		}
		addrs, e := it.Addrs()
		if e != nil {
			continue
		}
		for _, addr := range addrs {
			cidr, _, e := net.ParseCIDR(addr.String())
			if e == nil && cidr.To4() != nil && !cidr.IsLoopback() {
				return it.Name, cidr.String()
			}
		}
	}
	return "No active IPv4 adapter", ""
}
func networkProbe(ctx context.Context) NetworkResult {
	r := NetworkResult{Ran: true}
	r.Adapter, r.LocalIP = localAdapter()
	start := time.Now()
	dctx, dcancel := context.WithTimeout(ctx, 5*time.Second)
	_, e := net.DefaultResolver.LookupIPAddr(dctx, "example.com")
	r.DNSMillis = time.Since(start).Milliseconds()
	r.DNSOK = e == nil
	if e != nil {
		r.DNSReason = shortError(e)
	} else {
		r.DNSReason = "Domain name resolved successfully."
	}
	dcancel()
	start = time.Now()
	tctx, tcancel := context.WithTimeout(ctx, 5*time.Second)
	conn, e := (&net.Dialer{}).DialContext(tctx, "tcp", "1.1.1.1:443")
	r.TCPMillis = time.Since(start).Milliseconds()
	r.TCPOK = e == nil
	if e != nil {
		r.TCPReason = shortError(e)
	} else {
		r.TCPReason = "TCP connection established; not a bandwidth measurement."
		_ = conn.Close()
	}
	tcancel()
	return r
}
func shortError(e error) string {
	if e == nil {
		return ""
	}
	t := e.Error()
	if len(t) > 125 {
		t = t[:125] + "…"
	}
	return strings.TrimSpace(t)
}
