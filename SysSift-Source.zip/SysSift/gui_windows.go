//go:build windows

package main

import (
	"context"
	_ "embed"
	"errors"
	"fmt"
	"image"
	_ "image/png"
	"io"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"sync"
	"syscall"
	"time"
	"unsafe"
)

//go:embed assets/icon-256.png
var iconPNG []byte

const (
	wsOverlappedWindow = 0x00CF0000
	wsVisible          = 0x10000000
	wsClipChildren     = 0x02000000
	wmCreate           = 0x0001
	wmDestroy          = 0x0002
	wmSize             = 0x0005
	wmClose            = 0x0010
	wmPaint            = 0x000F
	wmEraseBkgnd       = 0x0014
	wmLButtonUp        = 0x0202
	wmMouseMove        = 0x0200
	wmMouseWheel       = 0x020A
	wmTimer            = 0x0113
	wmKeyDown          = 0x0100
	wmGetMinMaxInfo    = 0x0024
	wmSetIcon          = 0x0080
	wmAppNet           = 0x8001
	wmAppFolder        = 0x8002
	wmAppScanProgress  = 0x8003
	csHRedraw          = 0x0002
	csVRedraw          = 0x0001
	dtLeft             = 0x0
	dtCenter           = 0x1
	dtRight            = 0x2
	dtVCenter          = 0x4
	dtWordBreak        = 0x10
	dtSingleLine       = 0x20
	dtNoPrefix         = 0x800
	dtEndEllipsis      = 0x8000
	transparency       = 1
)

var (
	u32                     = syscall.NewLazyDLL("user32.dll")
	gdi                     = syscall.NewLazyDLL("gdi32.dll")
	msimg                   = syscall.NewLazyDLL("msimg32.dll")
	shell                   = syscall.NewLazyDLL("shell32.dll")
	ole                     = syscall.NewLazyDLL("ole32.dll")
	commdlg                 = syscall.NewLazyDLL("comdlg32.dll")
	k32                     = syscall.NewLazyDLL("kernel32.dll")
	pRegClass               = u32.NewProc("RegisterClassExW")
	pCreateWindow           = u32.NewProc("CreateWindowExW")
	pDefWindow              = u32.NewProc("DefWindowProcW")
	pShowWindow             = u32.NewProc("ShowWindow")
	pUpdateWindow           = u32.NewProc("UpdateWindow")
	pGetMessage             = u32.NewProc("GetMessageW")
	pTranslateMessage       = u32.NewProc("TranslateMessage")
	pDispatchMessage        = u32.NewProc("DispatchMessageW")
	pPostQuit               = u32.NewProc("PostQuitMessage")
	pDestroyWindow          = u32.NewProc("DestroyWindow")
	pPostMessage            = u32.NewProc("PostMessageW")
	pInvalidateRect         = u32.NewProc("InvalidateRect")
	pGetClientRect          = u32.NewProc("GetClientRect")
	pBeginPaint             = u32.NewProc("BeginPaint")
	pEndPaint               = u32.NewProc("EndPaint")
	pSetTimer               = u32.NewProc("SetTimer")
	pKillTimer              = u32.NewProc("KillTimer")
	pLoadCursor             = u32.NewProc("LoadCursorW")
	pSetCursor              = u32.NewProc("SetCursor")
	pSetWindowIcon          = u32.NewProc("SendMessageW")
	pMessageBox             = u32.NewProc("MessageBoxW")
	pGetSystemMetrics       = u32.NewProc("GetSystemMetrics")
	pDrawText               = u32.NewProc("DrawTextW")
	pSetTextColor           = gdi.NewProc("SetTextColor")
	pSetBkMode              = gdi.NewProc("SetBkMode")
	pCreateFont             = gdi.NewProc("CreateFontW")
	pCreateBrush            = gdi.NewProc("CreateSolidBrush")
	pCreatePen              = gdi.NewProc("CreatePen")
	pSelectObject           = gdi.NewProc("SelectObject")
	pDeleteObject           = gdi.NewProc("DeleteObject")
	pFillRect               = u32.NewProc("FillRect")
	pRoundRect              = gdi.NewProc("RoundRect")
	pEllipse                = gdi.NewProc("Ellipse")
	pMoveTo                 = gdi.NewProc("MoveToEx")
	pLineTo                 = gdi.NewProc("LineTo")
	pCreateCompatibleDC     = gdi.NewProc("CreateCompatibleDC")
	pDeleteDC               = gdi.NewProc("DeleteDC")
	pCreateCompatibleBitmap = gdi.NewProc("CreateCompatibleBitmap")
	pBitBlt                 = gdi.NewProc("BitBlt")
	pCreateDIBSection       = gdi.NewProc("CreateDIBSection")
	pAlphaBlend             = msimg.NewProc("AlphaBlend")
	pCreateIconIndirect     = u32.NewProc("CreateIconIndirect")
	pCreateMonoBitmap       = gdi.NewProc("CreateBitmap")
	pDestroyIcon            = u32.NewProc("DestroyIcon")
	pSHBrowse               = shell.NewProc("SHBrowseForFolderW")
	pSHGetPath              = shell.NewProc("SHGetPathFromIDListW")
	pShellExecute           = shell.NewProc("ShellExecuteW")
	pCoTaskMemFree          = ole.NewProc("CoTaskMemFree")
	pCoInit                 = ole.NewProc("CoInitializeEx")
	pCoUninit               = ole.NewProc("CoUninitialize")
	pGetSaveFile            = commdlg.NewProc("GetSaveFileNameW")
	pGetModule              = k32.NewProc("GetModuleHandleW")
)

type winRect struct{ Left, Top, Right, Bottom int32 }

func rc(x, y, w, h int32) winRect { return winRect{x, y, x + w, y + h} }
func (r winRect) contains(x, y int32) bool {
	return x >= r.Left && x < r.Right && y >= r.Top && y < r.Bottom
}
func (r winRect) W() int32        { return r.Right - r.Left }
func (r winRect) H() int32        { return r.Bottom - r.Top }
func rgbc(r, g, b uint32) uintptr { return uintptr(r | (g << 8) | (b << 16)) }

var (
	colorBG       = rgbc(237, 244, 252)
	colorSidebar  = rgbc(222, 234, 247)
	colorPanel    = rgbc(255, 255, 255)
	colorPanel2   = rgbc(234, 242, 252)
	colorBorder   = rgbc(195, 210, 228)
	colorInk      = rgbc(26, 42, 61)
	colorOnAccent = rgbc(255, 255, 255)
	colorMuted    = rgbc(95, 112, 132)
	colorDim      = rgbc(123, 140, 159)
	colorAccent   = rgbc(44, 160, 255)
	colorBlue     = rgbc(36, 122, 231)
	colorGreen    = rgbc(36, 176, 122)
	colorYellow   = rgbc(222, 156, 58)
	colorRed      = rgbc(214, 87, 84)
)

type winClassEx struct {
	Size, Style                        uint32
	WndProc                            uintptr
	ClsExtra, WndExtra                 int32
	Instance, Icon, Cursor, Background uintptr
	MenuName, ClassName                *uint16
	IconSmall                          uintptr
}
type winMsg struct {
	HWND           uintptr
	Message        uint32
	WParam, LParam uintptr
	Time           uint32
	X, Y           int32
	Private        uint32
}
type winPaint struct {
	Hdc                uintptr
	Erase              int32
	Paint              winRect
	Restore, IncUpdate int32
	RGBReserved        [32]byte
}
type minMaxInfo struct {
	PtReserved     [2]int32
	PtMaxSize      [2]int32
	PtMaxPosition  [2]int32
	PtMinTrackSize [2]int32
	PtMaxTrackSize [2]int32
}
type browseInfo struct {
	Owner, Root        uintptr
	DisplayName, Title *uint16
	Flags              uint32
	Callback, Param    uintptr
	Image              int32
}
type openFileName struct {
	Size                       uint32
	Owner, Instance            uintptr
	Filter, CustomFilter       *uint16
	MaxCustom, FilterIndex     uint32
	File                       *uint16
	MaxFile                    uint32
	FileTitle                  *uint16
	MaxFileTitle               uint32
	InitialDir, Title          *uint16
	Flags                      uint32
	FileOffset, FileExtension  uint16
	DefaultExtension           *uint16
	CustomData, Hook, Template uintptr
	Reserved                   uintptr
	Reserved32, FlagsEx        uint32
}
type bitmapInfoHeader struct {
	Size                   uint32
	Width, Height          int32
	Planes, BitCount       uint16
	Compression, SizeImage uint32
	XPels, YPels           int32
	ClrUsed, ClrImportant  uint32
}
type bitmapInfo struct {
	Header bitmapInfoHeader
	Colors [1]uint32
}
type iconInfo struct {
	IsIcon      int32
	HotX, HotY  uint32
	Mask, Color uintptr
}

type fontSet struct{ Hero, Heading, Title, Body, Medium, Small, Tiny uintptr }
type clickZone struct {
	Rect   winRect
	Action string
	Value  int
}
type appState struct {
	HWND                         uintptr
	Fonts                        fontSet
	Icon                         uintptr
	iconBMP                      uintptr
	iconDC                       uintptr
	sampler                      cpuSampler
	snap                         Snapshot
	latest                       Snapshot
	network                      NetworkResult
	folder                       FolderReport
	folderRoot                   string
	folderRunning, netRunning    bool
	folderCancel                 context.CancelFunc
	folderStatus, netStatus      string
	uiPage                       int
	zones                        []clickZone
	hover                        int
	scroll                       int32
	winW, winH                   int32
	selectedFolder, selectedFile int
	folderOffset                 int
	folderProgress               ScanProgress
	tick                         int
	syncMu                       sync.Mutex
	pendingNet                   NetworkResult
	pendingFolder                FolderReport
	pendingScanProgress          ScanProgress
	pendingErr                   error
}

var app appState
var pages = []string{"Overview", "Performance", "Storage", "Network", "System"}
var pageIcons = []string{"◆", "▥", "▣", "◎", "⚙"}

func sptr(s string) *uint16                                 { p, _ := syscall.UTF16PtrFromString(s); return p }
func hProc(proc *syscall.LazyProc, args ...uintptr) uintptr { r, _, _ := proc.Call(args...); return r }
func invalidate() {
	if app.HWND != 0 {
		pInvalidateRect.Call(app.HWND, 0, 0)
	}
}
func notify(title, message string) {
	pMessageBox.Call(app.HWND, uintptr(unsafe.Pointer(sptr(message))), uintptr(unsafe.Pointer(sptr(title))), 0x40)
}
func errorBox(message string) {
	pMessageBox.Call(app.HWND, uintptr(unsafe.Pointer(sptr(message))), uintptr(unsafe.Pointer(sptr("SysSift"))), 0x30)
}

func newFont(size int32, weight int32) uintptr {
	return hProc(pCreateFont, uintptr(^uintptr(uintptr(size-1))), 0, 0, 0, uintptr(weight), 0, 0, 0, 1, 0, 0, 0, 0, uintptr(unsafe.Pointer(sptr("Segoe UI"))))
}
func initFonts() {
	app.Fonts = fontSet{newFont(31, 700), newFont(24, 700), newFont(19, 700), newFont(15, 400), newFont(15, 600), newFont(13, 400), newFont(11, 400)}
}
func freeFonts() {
	for _, f := range []uintptr{app.Fonts.Hero, app.Fonts.Heading, app.Fonts.Title, app.Fonts.Body, app.Fonts.Medium, app.Fonts.Small, app.Fonts.Tiny} {
		if f != 0 {
			pDeleteObject.Call(f)
		}
	}
}
func solid(hdc uintptr, r winRect, col uintptr) {
	brush := hProc(pCreateBrush, col)
	pFillRect.Call(hdc, uintptr(unsafe.Pointer(&r)), brush)
	pDeleteObject.Call(brush)
}
func rounded(hdc uintptr, r winRect, radius int32, fill, border uintptr) {
	brush := hProc(pCreateBrush, fill)
	pen := hProc(pCreatePen, 0, 1, border)
	oldBrush := hProc(pSelectObject, hdc, brush)
	oldPen := hProc(pSelectObject, hdc, pen)
	pRoundRect.Call(hdc, uintptr(r.Left), uintptr(r.Top), uintptr(r.Right), uintptr(r.Bottom), uintptr(radius), uintptr(radius))
	pSelectObject.Call(hdc, oldPen)
	pSelectObject.Call(hdc, oldBrush)
	pDeleteObject.Call(pen)
	pDeleteObject.Call(brush)
}
func circle(hdc uintptr, r winRect, fill, border uintptr) {
	brush := hProc(pCreateBrush, fill)
	pen := hProc(pCreatePen, 0, 1, border)
	b := hProc(pSelectObject, hdc, brush)
	p := hProc(pSelectObject, hdc, pen)
	pEllipse.Call(hdc, uintptr(r.Left), uintptr(r.Top), uintptr(r.Right), uintptr(r.Bottom))
	pSelectObject.Call(hdc, p)
	pSelectObject.Call(hdc, b)
	pDeleteObject.Call(pen)
	pDeleteObject.Call(brush)
}
func drawText(hdc uintptr, text string, r winRect, font uintptr, color uintptr, flags uint32) {
	if text == "" {
		return
	}
	pSetTextColor.Call(hdc, color)
	pSetBkMode.Call(hdc, transparency)
	old := hProc(pSelectObject, hdc, font)
	t := syscall.StringToUTF16(text)
	pDrawText.Call(hdc, uintptr(unsafe.Pointer(&t[0])), uintptr(len(t)-1), uintptr(unsafe.Pointer(&r)), uintptr(flags|dtNoPrefix))
	pSelectObject.Call(hdc, old)
}
func line(hdc uintptr, x1, y1, x2, y2 int32, col uintptr) {
	pen := hProc(pCreatePen, 0, 1, col)
	old := hProc(pSelectObject, hdc, pen)
	pMoveTo.Call(hdc, uintptr(x1), uintptr(y1), 0)
	pLineTo.Call(hdc, uintptr(x2), uintptr(y2))
	pSelectObject.Call(hdc, old)
	pDeleteObject.Call(pen)
}
func textL(hdc uintptr, s string, x, y, w, h int32, font, color uintptr) {
	drawText(hdc, s, rc(x, y, w, h), font, color, dtSingleLine|dtVCenter|dtEndEllipsis)
}
func textWrap(hdc uintptr, s string, x, y, w, h int32, font, color uintptr) {
	drawText(hdc, s, rc(x, y, w, h), font, color, dtWordBreak)
}
func pill(hdc uintptr, s string, r winRect, bg, fg uintptr) {
	rounded(hdc, r, 20, bg, bg)
	drawText(hdc, s, r, app.Fonts.Small, fg, dtCenter|dtVCenter|dtSingleLine)
}
func press(hdc uintptr, title string, r winRect, action string, val int, primary bool) {
	id := len(app.zones)
	app.zones = append(app.zones, clickZone{r, action, val})
	fill := colorPanel2
	fg := colorInk
	edge := colorBorder
	if primary {
		fill = colorBlue
		edge = colorBlue
		fg = colorOnAccent
	}
	if app.hover == id {
		if primary {
			fill = rgbc(21, 111, 221)
		} else {
			fill = rgbc(222, 233, 245)
		}
	}
	rounded(hdc, r, 12, fill, edge)
	drawText(hdc, title, rc(r.Left+8, r.Top, r.W()-16, r.H()), app.Fonts.Medium, fg, dtSingleLine|dtCenter|dtVCenter|dtEndEllipsis)
}
func hit(r winRect, action string, value int) {
	app.zones = append(app.zones, clickZone{r, action, value})
}
func progress(hdc uintptr, r winRect, pct float64) {
	rounded(hdc, r, 8, rgbc(225, 235, 246), rgbc(225, 235, 246))
	p := clampPct(pct)
	filled := int32(float64(r.W()) * p / 100)
	if filled > 4 {
		rounded(hdc, rc(r.Left, r.Top, filled, r.H()), 8, colorAccent, colorAccent)
	}
}
func iconAt(hdc uintptr, x, y, size int32) {
	if app.iconDC == 0 {
		return
	}
	blend := uintptr(255<<16 | 1<<24)
	pAlphaBlend.Call(hdc, uintptr(x), uintptr(y), uintptr(size), uintptr(size), app.iconDC, 0, 0, 256, 256, blend)
}
func createLogoBitmap() {
	decoded, _, err := image.Decode(strings.NewReader(string(iconPNG)))
	if err != nil {
		return
	}
	bmp := bitmapInfo{Header: bitmapInfoHeader{Size: 40, Width: 256, Height: -256, Planes: 1, BitCount: 32, Compression: 0}}
	dc := hProc(pCreateCompatibleDC, 0)
	var pixels uintptr
	hb := hProc(pCreateDIBSection, dc, uintptr(unsafe.Pointer(&bmp)), 0, uintptr(unsafe.Pointer(&pixels)), 0, 0)
	if hb == 0 || pixels == 0 {
		pDeleteDC.Call(dc)
		return
	}
	canvas := unsafe.Slice((*byte)(unsafe.Pointer(pixels)), 256*256*4)
	bounds := decoded.Bounds()
	for y := 0; y < 256; y++ {
		for x := 0; x < 256; x++ {
			px := bounds.Min.X + x*bounds.Dx()/256
			py := bounds.Min.Y + y*bounds.Dy()/256
			r, g, b, a := decoded.At(px, py).RGBA()
			i := (y*256 + x) * 4
			// image.Image RGBA from .RGBA is premultiplied already; convert 16bit to 8bit.
			canvas[i], canvas[i+1], canvas[i+2], canvas[i+3] = byte(b>>8), byte(g>>8), byte(r>>8), byte(a>>8)
		}
	}
	app.iconBMP = hb
	hProc(pSelectObject, dc, hb)
	app.iconDC = dc
	// CreateIconIndirect receives a zeroed 1-bit mask plus the BGRA bitmap.
	maskBytes := make([]byte, (256*256)/8)
	mask := hProc(pCreateMonoBitmap, 256, 256, 1, 1, uintptr(unsafe.Pointer(&maskBytes[0])))
	if mask != 0 {
		ii := iconInfo{IsIcon: 1, Mask: mask, Color: hb}
		app.Icon = hProc(pCreateIconIndirect, uintptr(unsafe.Pointer(&ii)))
		pDeleteObject.Call(mask)
	}

}
func releaseLogo() {
	if app.Icon != 0 {
		pDestroyIcon.Call(app.Icon)
	}
	if app.iconDC != 0 {
		pDeleteDC.Call(app.iconDC)
	}
	if app.iconBMP != 0 {
		pDeleteObject.Call(app.iconBMP)
	}
}

func drawSidebar(hdc uintptr) {
	solid(hdc, rc(0, 0, 227, app.winH), colorSidebar)
	line(hdc, 226, 0, 226, app.winH, colorBorder)
	iconAt(hdc, 22, 24, 48)
	textL(hdc, "SysSift", 82, 26, 139, 32, app.Fonts.Heading, colorInk)
	textL(hdc, "SYSTEM INSIGHTS", 83, 55, 136, 20, app.Fonts.Tiny, colorAccent)
	textL(hdc, "Your PC, explained.", 24, 105, 176, 23, app.Fonts.Small, colorMuted)
	for i, name := range pages {
		y := int32(161 + i*59)
		r := rc(15, y, 197, 48)
		if app.uiPage == i {
			rounded(hdc, r, 12, rgbc(206, 227, 250), rgbc(206, 227, 250))
			solid(hdc, rc(15, y+10, 4, 28), colorBlue)
		}
		textL(hdc, pageIcons[i], 32, y+2, 30, 44, app.Fonts.Title, func() uintptr {
			if app.uiPage == i {
				return colorAccent
			}
			return colorMuted
		}())
		textL(hdc, name, 72, y+2, 120, 44, app.Fonts.Medium, func() uintptr {
			if app.uiPage == i {
				return colorBlue
			}
			return colorMuted
		}())
		hit(r, "nav", i)
	}
	y := app.winH - 137
	if y < 490 {
		return
	}
	line(hdc, 24, y, 199, y, colorBorder)
	circle(hdc, rc(25, y+22, 9, 9), colorGreen, colorGreen)
	textL(hdc, "Private by design", 42, y+14, 157, 25, app.Fonts.Medium, colorInk)
	textWrap(hdc, "No accounts. No telemetry. Nothing is changed automatically.", 25, y+49, 170, 60, app.Fonts.Small, colorMuted)
}
func currentSubtitle() string {
	switch app.uiPage {
	case 0:
		return "A clear picture of your PC, updated every two seconds."
	case 1:
		return "Live resource usage and the apps using the most memory."
	case 2:
		return "Drive space and a safe, read-only folder inspection."
	case 3:
		return "See your adapter and run optional connection tests."
	default:
		return "System details and transparent diagnostic checks."
	}
}

func headerStatusColor() uintptr {
	if app.netRunning {
		return colorBlue
	}
	if strings.Contains(strings.ToLower(app.netStatus), "fail") {
		return colorYellow
	}
	if strings.Contains(strings.ToLower(app.netStatus), "complete") {
		return colorGreen
	}
	return colorMuted
}
func drawHeader(hdc uintptr, x, w int32) {
	textL(hdc, pages[app.uiPage], x, 26, w-260, 41, app.Fonts.Hero, colorInk)
	textL(hdc, currentSubtitle(), x, 69, w-30, 22, app.Fonts.Body, colorMuted)
	if app.netStatus != "" {
		textL(hdc, app.netStatus, x, 90, w-320, 20, app.Fonts.Small, headerStatusColor())
	}
	press(hdc, "Export report", rc(x+w-290, 35, 132, 40), "export", 0, false)
	checkLabel := "Run checks"
	if app.netRunning {
		checkLabel = "Running..."
	}
	press(hdc, checkLabel, rc(x+w-144, 35, 144, 40), "all", 0, true)
	line(hdc, x, 112, x+w, 112, colorBorder)
}
func drawMetric(hdc uintptr, title, value, hint string, r winRect, pct float64, hasBar bool) {
	rounded(hdc, r, 16, colorPanel, colorBorder)
	textL(hdc, title, r.Left+19, r.Top+13, r.W()-32, 25, app.Fonts.Medium, colorMuted)
	textL(hdc, value, r.Left+19, r.Top+39, r.W()-38, 49, app.Fonts.Hero, colorInk)
	if hasBar {
		progress(hdc, rc(r.Left+19, r.Top+94, r.W()-38, 7), pct)
	}
	textL(hdc, hint, r.Left+19, r.Bottom-33, r.W()-38, 24, app.Fonts.Small, colorDim)
}
func pageLayout() (int32, int32) { return 258, app.winW - 287 }
func drawOverview(hdc uintptr, x, w int32) {
	avail := w
	gap := int32(14)
	cardW := (avail - gap*3) / 4
	d, exists := app.snap.PrimaryDisk()
	diskText := "N/A"
	diskHint := "No accessible drive"
	diskPct := 0.0
	if exists {
		diskPct = diskUsedPercent(d)
		diskText = fmt.Sprintf("%.0f%%", diskPct)
		diskHint = d.Name + "  " + humanBytes(d.Free) + " free"
	}
	drawMetric(hdc, "CPU USAGE", fmt.Sprintf("%.0f%%", app.snap.CPU), "Live system total", rc(x, 134, cardW, 153), app.snap.CPU, true)
	drawMetric(hdc, "MEMORY", fmt.Sprintf("%.0f%%", app.snap.RAMUsedPercent()), humanBytes(app.snap.RAMTotal-app.snap.RAMAvailable)+" of "+humanBytes(app.snap.RAMTotal), rc(x+cardW+gap, 134, cardW, 153), app.snap.RAMUsedPercent(), true)
	drawMetric(hdc, "SYSTEM DRIVE", diskText, diskHint, rc(x+2*(cardW+gap), 134, cardW, 153), diskPct, true)
	uptime := app.snap.Uptime
	ud := fmt.Sprintf("%dh %dm", int(uptime.Hours())%24, int(uptime.Minutes())%60)
	if uptime >= 24*time.Hour {
		ud = fmt.Sprintf("%dd %dh", int(uptime.Hours())/24, int(uptime.Hours())%24)
	}
	drawMetric(hdc, "UPTIME", ud, "Since last boot", rc(x+3*(cardW+gap), 134, cardW, 153), 0, false)
	leftW := (w * 59) / 100
	rightX := x + leftW + 14
	rightW := w - leftW - 14
	y := 307
	cardH := int32(323)
	rounded(hdc, rc(x, int32(y), leftW, cardH), 16, colorPanel, colorBorder)
	textL(hdc, "Diagnostic findings", x+20, int32(y)+14, leftW-40, 35, app.Fonts.Title, colorInk)
	small := combinedFindings(app.snap, app.network)
	max := 3
	if len(small) < 3 {
		max = len(small)
	}
	for i := 0; i < max; i++ {
		f := small[i]
		yy := int32(y + 58 + i*82)
		col := colorGreen
		lab := "INFO"
		if f.Severity == Warning {
			col = colorYellow
			lab = "CHECK"
		}
		if f.Severity == Critical {
			col = colorRed
			lab = "ALERT"
		}
		circle(hdc, rc(x+22, yy+8, 10, 10), col, col)
		textL(hdc, lab, x+43, yy, leftW-66, 23, app.Fonts.Tiny, col)
		textL(hdc, f.Title, x+111, yy-1, leftW-134, 27, app.Fonts.Medium, colorInk)
		textL(hdc, f.Reason, x+44, yy+24, leftW-69, 26, app.Fonts.Small, colorMuted)
		textL(hdc, "TIP: "+f.Advice, x+44, yy+49, leftW-69, 25, app.Fonts.Small, colorAccent)
		if i < max-1 {
			line(hdc, x+20, yy+74, x+leftW-20, yy+74, colorBorder)
		}
	}
	rounded(hdc, rc(rightX, int32(y), rightW, cardH), 16, colorPanel, colorBorder)
	textL(hdc, "Quick actions", rightX+20, int32(y)+14, rightW-40, 35, app.Fonts.Title, colorInk)
	textWrap(hdc, "Use focused checks instead of mystery 'boost' buttons.", rightX+20, int32(y)+56, rightW-40, 50, app.Fonts.Small, colorMuted)
	qy := int32(y) + 123
	press(hdc, "Inspect folder sizes", rc(rightX+18, qy, rightW-36, 40), "storage", 0, false)
	press(hdc, "Test network connection", rc(rightX+18, qy+52, rightW-36, 40), "network", 0, false)
	press(hdc, "See resource-heavy apps", rc(rightX+18, qy+104, rightW-36, 40), "performance", 0, false)
	textL(hdc, "Read-only diagnostics", x, 655, w-10, 23, app.Fonts.Small, colorDim)
	textWrap(hdc, "Threshold warnings are clues, not proof of a fault. SysSift never auto-deletes files or changes Windows settings.", x, 682, w-12, 44, app.Fonts.Small, colorMuted)
}
func drawPerformance(hdc uintptr, x, w int32) {
	gap := int32(16)
	half := (w - gap) / 2
	drawMetric(hdc, "TOTAL CPU LOAD", fmt.Sprintf("%.0f%%", app.snap.CPU), fmt.Sprintf("%d logical processors", app.snap.CPUs), rc(x, 134, half, 149), app.snap.CPU, true)
	drawMetric(hdc, "PHYSICAL MEMORY", humanBytes(app.snap.RAMTotal-app.snap.RAMAvailable), humanBytes(app.snap.RAMAvailable)+" available", rc(x+half+gap, 134, half, 149), app.snap.RAMUsedPercent(), true)
	tableY := int32(300)
	tableH := app.winH - 345
	if tableH < 250 {
		tableH = 250
	}
	rounded(hdc, rc(x, tableY, w, tableH), 16, colorPanel, colorBorder)
	textL(hdc, "Highest memory processes", x+22, tableY+15, w-45, 35, app.Fonts.Title, colorInk)
	textL(hdc, "Snapshot of working-set memory. Some protected processes may be unavailable.", x+22, tableY+51, w-44, 25, app.Fonts.Small, colorMuted)
	headerY := tableY + 88
	solid(hdc, rc(x+16, headerY, w-32, 31), colorPanel2)
	textL(hdc, "PROCESS", x+28, headerY, w/2, 31, app.Fonts.Small, colorMuted)
	textL(hdc, "PID", x+w-243, headerY, 80, 31, app.Fonts.Small, colorMuted)
	textL(hdc, "MEMORY", x+w-138, headerY, 115, 31, app.Fonts.Small, colorMuted)
	start := headerY + 36
	for i, p := range app.snap.Processes {
		yy := start + int32(i)*35
		if yy+33 > tableY+tableH-12 {
			break
		}
		if i%2 == 0 {
			solid(hdc, rc(x+17, yy, w-34, 34), rgbc(245, 249, 253))
		}
		textL(hdc, p.Name, x+27, yy, w/2+10, 33, app.Fonts.Body, colorInk)
		textL(hdc, fmt.Sprintf("%d", p.PID), x+w-243, yy, 80, 33, app.Fonts.Small, colorMuted)
		textL(hdc, humanBytes(p.Memory), x+w-138, yy, 115, 33, app.Fonts.Medium, colorInk)
	}
	if len(app.snap.Processes) == 0 {
		textL(hdc, "Process data unavailable or refreshing.", x+23, start+11, w-45, 34, app.Fonts.Body, colorMuted)
	}
}
func drawStorage(hdc uintptr, x, w int32) {
	// Prioritize ranked results over an oversized drive-capacity card.
	rounded(hdc, rc(x, 131, w, 68), 13, colorPanel, colorBorder)
	d, foundDrive := app.snap.PrimaryDisk()
	if foundDrive {
		textL(hdc, fmt.Sprintf("%s  •  %s free of %s", d.Name, humanBytes(d.Free), humanBytes(d.Total)), x+17, 139, w-200, 25, app.Fonts.Medium, colorInk)
		textL(hdc, fmt.Sprintf("%.0f%% used", diskUsedPercent(d)), x+w-152, 139, 129, 25, app.Fonts.Medium, colorBlue)
		progress(hdc, rc(x+18, 175, w-36, 7), diskUsedPercent(d))
	} else {
		textL(hdc, "No drive information available", x+18, 150, w-36, 27, app.Fonts.Medium, colorMuted)
	}
	y := int32(207)
	h := app.winH - y - 30
	if h < 345 {
		h = 345
	}
	rounded(hdc, rc(x, y, w, h), 16, colorPanel, colorBorder)
	textL(hdc, "Largest files and folders", x+20, y+12, w-221, 31, app.Fonts.Title, colorInk)
	driveLabel := "Scan C: drive"
	drive, hasDrive := app.snap.PrimaryDisk()
	if hasDrive {
		driveLabel = "Scan " + drive.Name + " drive"
	}
	press(hdc, driveLabel, rc(x+w-192, y+12, 173, 34), "scan-drive", 0, true)
	textL(hdc, "See the biggest items anywhere inside a drive or folder. No files are changed.", x+20, y+45, w-40, 22, app.Fonts.Small, colorMuted)
	rowY := y + 62
	rounded(hdc, rc(x+20, rowY, w-283, 38), 10, rgbc(248, 251, 255), colorBorder)
	label := app.folderRoot
	if label == "" {
		label = "Choose a folder"
	}
	textL(hdc, label, x+34, rowY+1, w-310, 35, app.Fonts.Small, colorInk)
	press(hdc, "Browse", rc(x+w-250, rowY, 104, 38), "browse", 0, false)
	scanLabel := "Scan folder"
	if app.folderRunning {
		scanLabel = "Cancel scan"
	}
	press(hdc, scanLabel, rc(x+w-134, rowY, 116, 38), "scan-folder", 0, true)
	statusText := app.folderStatus
	if app.folderRunning {
		statusText = fmt.Sprintf("Scanning: %d files, %s found, %d inaccessible/skipped. Cancel anytime.", app.folderProgress.Files, humanBytes(app.folderProgress.Bytes), app.folderProgress.Skipped)
	}
	textL(hdc, statusText, x+22, rowY+42, w-42, 23, app.Fonts.Small, func() uintptr {
		if app.folderRunning {
			return colorBlue
		}
		return colorMuted
	}())
	ty := rowY + 66
	line(hdc, x+20, ty-7, x+w-20, ty-7, colorBorder)
	if app.folder.Root == "" {
		textL(hdc, "Start with Scan C: drive to discover what's filling your disk.", x+23, ty+22, w-44, 30, app.Fonts.Body, colorInk)
		textWrap(hdc, "The scan lists the largest folders across all accessible subdirectories and the largest individual files. Protected folders and system metadata may not be counted.", x+23, ty+57, w-50, 65, app.Fonts.Small, colorMuted)
		return
	}
	if app.folder.Truncated || app.folder.Skipped > 0 {
		warning := "Partial results: "
		if app.folder.Truncated {
			warning += "scan safety limit reached"
		}
		if app.folder.Skipped > 0 {
			if app.folder.Truncated {
				warning += "; "
			}
			warning += fmt.Sprintf("%d entries inaccessible or skipped", app.folder.Skipped)
		}
		textL(hdc, warning, x+22, ty-4, w-44, 21, app.Fonts.Small, colorYellow)
	} else {
		textL(hdc, fmt.Sprintf("Scanned %s in %d files", humanBytes(app.folder.Total), app.folder.Files), x+22, ty-4, w-44, 21, app.Fonts.Small, colorGreen)
	}
	// Rankings are side by side, so both the largest directories and largest
	// individual files are visible at the same time.
	colGap := int32(13)
	colW := (w - 44 - colGap) / 2
	leftX := x + 20
	rightX := leftX + colW + colGap
	headY := ty + 17
	rounded(hdc, rc(leftX, headY, colW, 31), 8, colorPanel2, colorPanel2)
	rounded(hdc, rc(rightX, headY, colW, 31), 8, colorPanel2, colorPanel2)
	textL(hdc, "LARGEST FOLDERS", leftX+11, headY+1, colW-18, 29, app.Fonts.Small, colorInk)
	textL(hdc, "LARGEST FILES", rightX+11, headY+1, colW-18, 29, app.Fonts.Small, colorInk)
	startY := headY + 35
	availableBottom := y + h - 75
	count := int((availableBottom - startY) / 33)
	if count < 1 {
		count = 1
	}
	if count > 10 {
		count = 10
	}
	start := app.folderOffset * count
	drawStorageList := func(items int, left int32, folder bool) {
		for i := 0; i < count && start+i < items; i++ {
			idx := start + i
			yy := startY + int32(i*33)
			rr := rc(left, yy, colW, 31)
			chosen := (folder && app.selectedFolder == idx) || (!folder && app.selectedFile == idx)
			if chosen {
				rounded(hdc, rr, 8, rgbc(218, 235, 252), rgbc(218, 235, 252))
			}
			name := ""
			sz := uint64(0)
			action := "select-folder"
			if folder {
				f := app.folder.LargestFolders[idx]
				name, sz = f.Name, f.Bytes
			} else {
				f := app.folder.LargestFiles[idx]
				name, sz = f.Name, f.Bytes
				action = "select-file"
			}
			textL(hdc, fmt.Sprintf("%d. %s", idx+1, name), rr.Left+8, rr.Top, rr.W()-110, rr.H(), app.Fonts.Small, colorInk)
			drawText(hdc, humanBytes(sz), rc(rr.Right-109, rr.Top, 100, rr.H()), app.Fonts.Small, colorBlue, dtRight|dtVCenter|dtSingleLine)
			hit(rr, action, idx)
		}
	}
	drawStorageList(len(app.folder.LargestFolders), leftX, true)
	drawStorageList(len(app.folder.LargestFiles), rightX, false)
	if len(app.folder.LargestFolders) == 0 {
		textL(hdc, "No folders found.", leftX+10, startY+4, colW-20, 29, app.Fonts.Small, colorMuted)
	}
	if len(app.folder.LargestFiles) == 0 {
		textL(hdc, "No files found.", rightX+10, startY+4, colW-20, 29, app.Fonts.Small, colorMuted)
	}
	bottomY := y + h - 57
	selectedPath := "Click an item to see its full location."
	if app.selectedFile >= 0 && app.selectedFile < len(app.folder.LargestFiles) {
		selectedPath = app.folder.LargestFiles[app.selectedFile].Path
	}
	if app.selectedFolder >= 0 && app.selectedFolder < len(app.folder.LargestFolders) {
		selectedPath = app.folder.LargestFolders[app.selectedFolder].Path
	}
	textL(hdc, selectedPath, x+24, bottomY-15, w-255, 21, app.Fonts.Small, colorMuted)
	press(hdc, "Open selected", rc(x+w-181, bottomY-11, 160, 31), "open-folder", 0, false)
	pagerY := bottomY + 22
	textL(hdc, fmt.Sprintf("Showing ranks %d-%d of top %d", start+1, start+count, topResultCount), x+23, pagerY, w-248, 20, app.Fonts.Tiny, colorDim)
	if app.folderOffset > 0 {
		press(hdc, "Previous", rc(x+w-180, pagerY-2, 83, 24), "page-prev", 0, false)
	}
	if start+count < len(app.folder.LargestFolders) || start+count < len(app.folder.LargestFiles) {
		press(hdc, "Next", rc(x+w-91, pagerY-2, 69, 24), "page-next", 0, false)
	}
}
func drawNetwork(hdc uintptr, x, w int32) {
	rounded(hdc, rc(x, 134, w, 160), 16, colorPanel, colorBorder)
	textL(hdc, "Current adapter", x+22, 149, w-45, 34, app.Fonts.Title, colorInk)
	adapter, ip := localAdapter()
	if app.network.Ran && app.network.Adapter != "" {
		adapter, ip = app.network.Adapter, app.network.LocalIP
	}
	textL(hdc, adapter, x+23, 190, w/2-45, 33, app.Fonts.Heading, colorInk)
	textL(hdc, "LOCAL IP ADDRESS", x+w/2+14, 190, w/2-28, 22, app.Fonts.Small, colorMuted)
	if ip == "" {
		ip = "Not available"
	}
	textL(hdc, ip, x+w/2+14, 216, w/2-28, 34, app.Fonts.Title, colorAccent)
	textL(hdc, "Local adapter detection does not guarantee internet access.", x+23, 258, w-43, 23, app.Fonts.Small, colorDim)
	y := int32(313)
	rounded(hdc, rc(x, y, w, 116), 16, colorPanel, colorBorder)
	textL(hdc, "Connection tests", x+21, y+12, w-41, 32, app.Fonts.Title, colorInk)
	textL(hdc, "Initiated only when you click. Tests DNS resolution and outbound TCP connectivity.", x+22, y+48, w-245, 48, app.Fonts.Small, colorMuted)
	b := "Run network tests"
	if app.netRunning {
		b = "Testing..."
	}
	press(hdc, b, rc(x+w-211, y+44, 189, 43), "network-test", 0, true)
	cy := int32(449)
	cw := (w - 16) / 2
	drawNetworkCard(hdc, rc(x, cy, cw, 174), "DNS resolution", "example.com", app.network.DNSOK, app.network.DNSMillis, app.network.DNSReason, app.network.Ran)
	drawNetworkCard(hdc, rc(x+cw+16, cy, cw, 174), "TCP reachability", "1.1.1.1:443", app.network.TCPOK, app.network.TCPMillis, app.network.TCPReason, app.network.Ran)
	textWrap(hdc, "A failed test can be caused by DNS filtering, firewalls, VPNs, or an offline connection. SysSift does not measure internet speed and never silently changes network settings.", x+3, 644, w-9, 70, app.Fonts.Small, colorMuted)
}
func drawNetworkCard(hdc uintptr, r winRect, title, endpoint string, success bool, ms int64, reason string, ran bool) {
	rounded(hdc, r, 16, colorPanel, colorBorder)
	textL(hdc, title, r.Left+20, r.Top+13, r.W()-43, 30, app.Fonts.Title, colorInk)
	textL(hdc, endpoint, r.Left+20, r.Top+43, r.W()-43, 23, app.Fonts.Small, colorDim)
	state := "NOT TESTED"
	col := colorMuted
	if ran {
		if success {
			state = "PASSED"
			col = colorGreen
		} else {
			state = "FAILED"
			col = colorYellow
		}
	}
	pill(hdc, state, rc(r.Left+19, r.Top+83, 112, 28), colorPanel2, col)
	if ran {
		textL(hdc, fmt.Sprintf("%d ms", ms), r.Right-102, r.Top+84, 82, 26, app.Fonts.Medium, colorInk)
	}
	if reason != "" {
		textL(hdc, reason, r.Left+20, r.Bottom-45, r.W()-40, 31, app.Fonts.Small, colorMuted)
	}
}
func drawSystem(hdc uintptr, x, w int32) {
	left := (w * 45) / 100
	gap := int32(16)
	right := w - left - gap
	rounded(hdc, rc(x, 134, left, 352), 16, colorPanel, colorBorder)
	textL(hdc, "Computer information", x+20, 149, left-40, 33, app.Fonts.Title, colorInk)
	rows := [][2]string{{"Windows", app.snap.OS}, {"Computer", app.snap.Hostname}, {"Processor threads", fmt.Sprintf("%d logical cores", app.snap.CPUs)}, {"Installed RAM", humanBytes(app.snap.RAMTotal)}, {"Uptime", app.snap.Uptime.Truncate(time.Minute).String()}}
	for i, row := range rows {
		yy := int32(200 + i*53)
		textL(hdc, row[0], x+21, yy, left-40, 19, app.Fonts.Small, colorMuted)
		textL(hdc, row[1], x+21, yy+20, left-38, 25, app.Fonts.Medium, colorInk)
	}
	rx := x + left + gap
	rounded(hdc, rc(rx, 134, right, 352), 16, colorPanel, colorBorder)
	textL(hdc, "Health check summary", rx+20, 149, right-40, 33, app.Fonts.Title, colorInk)
	fs := combinedFindings(app.snap, app.network)
	for i, f := range fs {
		if i >= 4 {
			break
		}
		yy := int32(202 + i*63)
		c := colorGreen
		if f.Severity == Warning {
			c = colorYellow
		}
		circle(hdc, rc(rx+22, yy+8, 10, 10), c, c)
		textL(hdc, f.Title, rx+43, yy, right-65, 25, app.Fonts.Medium, colorInk)
		textL(hdc, f.Reason, rx+43, yy+27, right-65, 23, app.Fonts.Small, colorMuted)
	}
	y := int32(506)
	rounded(hdc, rc(x, y, w, 166), 16, colorPanel, colorBorder)
	textL(hdc, "What this scanner can and cannot tell you", x+20, y+14, w-40, 33, app.Fonts.Title, colorInk)
	textWrap(hdc, "SysSift checks basic usage thresholds, accessible drives, running processes and optional network reachability. It does not detect malware, predict hardware failure, read SMART data, repair Windows automatically, or guarantee that a PC is healthy.", x+21, y+55, w-42, 90, app.Fonts.Body, colorMuted)
}
func render(hdc uintptr) {
	var r winRect
	pGetClientRect.Call(app.HWND, uintptr(unsafe.Pointer(&r)))
	app.winW, app.winH = r.W(), r.H()
	if app.winW < 1 || app.winH < 1 {
		return
	}
	memDC := hProc(pCreateCompatibleDC, hdc)
	hb := hProc(pCreateCompatibleBitmap, hdc, uintptr(app.winW), uintptr(app.winH))
	if hb == 0 {
		pDeleteDC.Call(memDC)
		return
	}
	old := hProc(pSelectObject, memDC, hb)
	solid(memDC, rc(0, 0, app.winW, app.winH), colorBG)
	app.zones = app.zones[:0]
	drawSidebar(memDC)
	x, w := pageLayout()
	if w < 430 {
		w = 430
	}
	drawHeader(memDC, x, w)
	switch app.uiPage {
	case 0:
		drawOverview(memDC, x, w)
	case 1:
		drawPerformance(memDC, x, w)
	case 2:
		drawStorage(memDC, x, w)
	case 3:
		drawNetwork(memDC, x, w)
	case 4:
		drawSystem(memDC, x, w)
	}
	textL(memDC, "SysSift v0.2.0   •   Open source   •   Read-only by default", x, app.winH-29, w-5, 17, app.Fonts.Tiny, colorDim)
	pBitBlt.Call(hdc, 0, 0, uintptr(app.winW), uintptr(app.winH), memDC, 0, 0, 0xCC0020)
	pSelectObject.Call(memDC, old)
	pDeleteObject.Call(hb)
	pDeleteDC.Call(memDC)
}

func doAction(z clickZone) {
	switch z.Action {
	case "nav":
		app.uiPage = z.Value
		invalidate()
	case "storage":
		app.uiPage = 2
		invalidate()
	case "network":
		app.uiPage = 3
		invalidate()
	case "performance":
		app.uiPage = 1
		invalidate()
	case "all":
		app.uiPage = 0
		app.netStatus = "Running overview and network checks..."
		refreshSnapshot(true)
		startNetwork()
	case "network-test":
		startNetwork()
	case "browse":
		browseFolder()
	case "scan-folder":
		startFolderScan()
	case "select-folder":
		app.selectedFolder = z.Value
		app.selectedFile = -1
		invalidate()
	case "select-file":
		app.selectedFile = z.Value
		app.selectedFolder = -1
		invalidate()
	case "page-next":
		app.folderOffset++
		invalidate()
	case "page-prev":
		if app.folderOffset > 0 {
			app.folderOffset--
		}
		invalidate()
	case "scan-drive":
		if app.folderRunning {
			if app.folderCancel != nil {
				app.folderCancel()
			}
			break
		}
		if d, ok := app.snap.PrimaryDisk(); ok {
			app.folderRoot = d.Name
			startFolderScan()
		} else {
			errorBox("No accessible drive found to scan.")
		}
	case "open-folder":
		openSelectedFolder()
	case "export":
		exportReport()
	}
}
func refreshSnapshot(withProcesses bool) {
	s := basicSnapshot(&app.sampler, withProcesses)
	if !withProcesses {
		s.Processes = app.snap.Processes
	}
	app.snap = s
	invalidate()
}
func startNetwork() {
	if app.netRunning {
		return
	}
	app.netRunning = true
	app.netStatus = "Running network checks..."
	invalidate()
	go func() {
		ctx, cancel := context.WithTimeout(context.Background(), 12*time.Second)
		defer cancel()
		res := networkProbe(ctx)
		app.syncMu.Lock()
		app.pendingNet = res
		app.syncMu.Unlock()
		pPostMessage.Call(app.HWND, wmAppNet, 0, 0)
	}()
}
func startFolderScan() {
	if app.folderRunning {
		if app.folderCancel != nil {
			app.folderCancel()
		}
		return
	}
	if app.folderRoot == "" {
		errorBox("Choose a folder first.")
		return
	}
	ctx, cancel := context.WithCancel(context.Background())
	app.folderCancel = cancel
	app.folderRunning = true
	app.folderProgress = ScanProgress{}
	app.folderStatus = "Scanning in the background. You can cancel at any time."
	app.folder = FolderReport{}
	app.folderOffset = 0
	app.selectedFolder, app.selectedFile = -1, -1
	invalidate()
	root := app.folderRoot
	go func() {
		r, e := InspectFolderWithProgress(ctx, root, func(pr ScanProgress) {
			app.syncMu.Lock()
			app.pendingScanProgress = pr
			app.syncMu.Unlock()
			pPostMessage.Call(app.HWND, wmAppScanProgress, 0, 0)
		})
		app.syncMu.Lock()
		app.pendingFolder, app.pendingErr = r, e
		app.syncMu.Unlock()
		pPostMessage.Call(app.HWND, wmAppFolder, 0, 0)
	}()
}
func browseFolder() {
	var name [260]uint16
	bi := browseInfo{Owner: app.HWND, DisplayName: &name[0], Title: sptr("Choose a folder to inspect (read-only)"), Flags: 0x00000040 | 0x1}
	pidl := hProc(pSHBrowse, uintptr(unsafe.Pointer(&bi)))
	if pidl == 0 {
		return
	}
	defer pCoTaskMemFree.Call(pidl)
	buf := make([]uint16, 32768)
	ok := hProc(pSHGetPath, pidl, uintptr(unsafe.Pointer(&buf[0])))
	if ok == 0 {
		return
	}
	choice := syscall.UTF16ToString(buf)
	if choice == "" {
		return
	}
	app.folderRoot = choice
	app.folder = FolderReport{}
	app.selectedFolder, app.selectedFile = -1, -1
	app.folderOffset = 0
	app.folderStatus = "Ready to inspect. No files will be modified."
	invalidate()
}
func openSelectedFolder() {
	target := ""
	if app.selectedFile >= 0 && app.selectedFile < len(app.folder.LargestFiles) {
		target = app.folder.LargestFiles[app.selectedFile].Path
	} else if app.selectedFolder >= 0 && app.selectedFolder < len(app.folder.LargestFolders) {
		target = app.folder.LargestFolders[app.selectedFolder].Path
	}
	if target == "" {
		errorBox("Click a file or folder in the results first.")
		return
	}
	info, err := os.Stat(target)
	if err != nil {
		errorBox("Could not locate the item: " + err.Error())
		return
	}
	var parameters *uint16
	operation := sptr("open")
	if !info.IsDir() {
		parameters = sptr("/select,\"" + target + "\"")
		target = "explorer.exe"
	}
	res := hProc(pShellExecute, app.HWND, uintptr(unsafe.Pointer(operation)), uintptr(unsafe.Pointer(sptr(target))), uintptr(unsafe.Pointer(parameters)), 0, 1)
	if res <= 32 {
		errorBox("Could not open this item in Explorer.")
	}
}

func exportReport() {
	f := make([]uint16, 2048)
	copy(f, syscall.StringToUTF16("SysSift-report.txt"))
	filter := syscall.StringToUTF16("Text report (*.txt)\x00*.txt\x00All files (*.*)\x00*.*\x00\x00")
	o := openFileName{Size: uint32(unsafe.Sizeof(openFileName{})), Owner: app.HWND, Filter: &filter[0], File: &f[0], MaxFile: uint32(len(f)), Title: sptr("Save SysSift report"), Flags: 0x00000002 | 0x00000800 | 0x00000004}
	if hProc(pGetSaveFile, uintptr(unsafe.Pointer(&o))) == 0 {
		return
	}
	path := syscall.UTF16ToString(f)
	if !strings.EqualFold(filepath.Ext(path), ".txt") {
		path += ".txt"
	}
	if err := os.WriteFile(path, []byte(reportText(app.snap, app.network, app.folder)), 0600); err != nil {
		errorBox("Could not save the report: " + err.Error())
		return
	}
	notify("Report saved", "Saved a privacy-conscious text report to:\n"+path)
}

func windowProc(hwnd uintptr, msg uint32, w, l uintptr) uintptr {
	switch msg {
	case wmCreate:
		app.HWND = hwnd
		initFonts()
		createLogoBitmap()
		if app.Icon != 0 {
			pSetWindowIcon.Call(hwnd, wmSetIcon, 1, app.Icon)
			pSetWindowIcon.Call(hwnd, wmSetIcon, 0, app.Icon)
		}
		app.folderRoot = defaultFolder()
		app.folderStatus = "Choose a folder and click Scan folder. No files will be changed."
		app.netStatus = "Ready to run checks."
		app.selectedFolder, app.selectedFile = -1, -1
		app.snap = basicSnapshot(&app.sampler, true)
		pSetTimer.Call(hwnd, 1, 2000, 0)
		return 0
	case wmDestroy:
		if app.folderCancel != nil {
			app.folderCancel()
		}
		pKillTimer.Call(hwnd, 1)
		freeFonts()
		releaseLogo()
		pPostQuit.Call(0)
		return 0
	case wmClose:
		pDestroyWindow.Call(hwnd)
		return 0
	case wmGetMinMaxInfo:
		mm := (*minMaxInfo)(unsafe.Pointer(l))
		mm.PtMinTrackSize = [2]int32{1050, 730}
		return 0
	case wmEraseBkgnd:
		return 1
	case wmSize:
		invalidate()
		return 0
	case wmPaint:
		var ps winPaint
		hdc := hProc(pBeginPaint, hwnd, uintptr(unsafe.Pointer(&ps)))
		render(hdc)
		pEndPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))
		return 0
	case wmTimer:
		app.tick++
		refreshSnapshot(app.tick%2 == 0 || app.uiPage == 1)
		return 0
	case wmMouseMove:
		mx, my := int32(int16(l&0xffff)), int32(int16((l>>16)&0xffff))
		idx := -1
		for i, z := range app.zones {
			if z.Rect.contains(mx, my) {
				idx = i
				break
			}
		}
		if idx != app.hover {
			app.hover = idx
			invalidate()
		}
		if idx >= 0 {
			pSetCursor.Call(hProc(pLoadCursor, 0, 32649))
		}
		return 0
	case wmLButtonUp:
		mx, my := int32(int16(l&0xffff)), int32(int16((l>>16)&0xffff))
		for _, z := range app.zones {
			if z.Rect.contains(mx, my) {
				doAction(z)
				break
			}
		}
		return 0
	case wmKeyDown:
		if w == 0x74 {
			refreshSnapshot(true)
			return 0
		} // F5
		if w == 0x1B && app.folderRunning {
			if app.folderCancel != nil {
				app.folderCancel()
			}
			return 0
		}
	case wmAppNet:
		app.syncMu.Lock()
		app.network = app.pendingNet
		app.syncMu.Unlock()
		app.netRunning = false
		app.netStatus = fmt.Sprintf("Checks completed at %s", time.Now().Format("3:04 PM"))
		invalidate()
		return 0
	case wmAppScanProgress:
		app.syncMu.Lock()
		app.folderProgress = app.pendingScanProgress
		app.syncMu.Unlock()
		if app.folderRunning {
			invalidate()
		}
		return 0
	case wmAppFolder:
		app.syncMu.Lock()
		r, e := app.pendingFolder, app.pendingErr
		app.syncMu.Unlock()
		app.folderRunning = false
		app.folderCancel = nil
		app.folder = r
		app.selectedFolder = -1
		if e != nil {
			if errors.Is(e, context.Canceled) {
				app.folderStatus = "Scan cancelled. Partial findings shown where available."
			} else {
				app.folderStatus = "Scan failed: " + e.Error()
			}
		} else {
			app.folderStatus = fmt.Sprintf("Completed in %s. %d files, %d skipped entries.", r.Duration.Round(time.Millisecond), r.Files, r.Skipped)
			if r.Truncated {
				app.folderStatus += " Safety limit reached; results are incomplete."
			}
		}
		invalidate()
		return 0
	}
	return hProc(pDefWindow, hwnd, uintptr(msg), w, l)
}
func defaultFolder() string {
	home, e := os.UserHomeDir()
	if e == nil {
		return home
	}
	return ""
}
func runGUI() error {
	runtime.LockOSThread()
	defer runtime.UnlockOSThread()
	pCoInit.Call(0, 2)
	defer pCoUninit.Call()
	instance := hProc(pGetModule, 0)
	cname := sptr("SysSiftDesktopWindow")
	cls := winClassEx{Size: uint32(unsafe.Sizeof(winClassEx{})), Style: csHRedraw | csVRedraw, WndProc: syscall.NewCallback(windowProc), Instance: instance, ClassName: cname, Cursor: hProc(pLoadCursor, 0, 32512)}
	if hProc(pRegClass, uintptr(unsafe.Pointer(&cls))) == 0 {
		return errors.New("could not register application window")
	}
	sx := int32(hProc(pGetSystemMetrics, 0))
	sy := int32(hProc(pGetSystemMetrics, 1))
	width, height := int32(1240), int32(805)
	if width > sx-80 {
		width = sx - 40
	}
	if height > sy-75 {
		height = sy - 60
	}
	if width < 950 {
		width = 1050
	}
	if height < 650 {
		height = 730
	}
	x := (sx - width) / 2
	y := (sy - height) / 2
	hwnd := hProc(pCreateWindow, 0, uintptr(unsafe.Pointer(cname)), uintptr(unsafe.Pointer(sptr("SysSift | Windows PC diagnostics"))), wsOverlappedWindow|wsVisible|wsClipChildren, uintptr(x), uintptr(y), uintptr(width), uintptr(height), 0, 0, instance, 0)
	if hwnd == 0 {
		return errors.New("could not create application window")
	}
	app.HWND = hwnd
	pShowWindow.Call(hwnd, 5)
	pUpdateWindow.Call(hwnd)
	var m winMsg
	for {
		r, _, _ := pGetMessage.Call(uintptr(unsafe.Pointer(&m)), 0, 0, 0)
		if int32(r) <= 0 {
			break
		}
		pTranslateMessage.Call(uintptr(unsafe.Pointer(&m)))
		pDispatchMessage.Call(uintptr(unsafe.Pointer(&m)))
	}
	return nil
}
func main() {
	if err := runGUI(); err != nil {
		_, _ = io.WriteString(os.Stderr, err.Error())
		pMessageBox.Call(0, uintptr(unsafe.Pointer(sptr(err.Error()))), uintptr(unsafe.Pointer(sptr("SysSift startup error"))), 0x10)
	}
}
