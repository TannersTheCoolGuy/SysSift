package main

import (
	"container/heap"
	"context"
	"errors"
	"os"
	"path/filepath"
	"sort"
	"time"
)

type FolderSize struct {
	Name  string
	Path  string
	Bytes uint64
	Files uint64
}

type FileSize struct {
	Name  string
	Path  string
	Bytes uint64
}

type FolderReport struct {
	Root           string
	Total, Files   uint64
	Skipped        int
	Truncated      bool
	Duration       time.Duration
	Folders        []FolderSize // immediate children, kept for backward compatibility
	LargestFolders []FolderSize // largest directories anywhere under Root
	LargestFiles   []FileSize   // largest regular files anywhere under Root
}

type ScanProgress struct {
	Files, Directories, Bytes uint64
	Skipped                   int
}

// Limits cap memory, UI latency and runtime on huge drives; results show when incomplete.
const maxScanFiles uint64 = 1000000
const maxScanDirs = 175000
const topResultCount = 60

type scanDir struct {
	path   string
	parent int
	bytes  uint64
	files  uint64
}

type fileMinHeap []FileSize

func (h fileMinHeap) Len() int            { return len(h) }
func (h fileMinHeap) Less(i, j int) bool  { return h[i].Bytes < h[j].Bytes }
func (h fileMinHeap) Swap(i, j int)       { h[i], h[j] = h[j], h[i] }
func (h *fileMinHeap) Push(x interface{}) { *h = append(*h, x.(FileSize)) }
func (h *fileMinHeap) Pop() interface{} {
	x := *h
	n := len(x)
	v := x[n-1]
	*h = x[:n-1]
	return v
}

// InspectFolder reads file metadata only and does not follow directory symlinks
// or Windows reparse points. It can return a partial, clearly labelled report.
func InspectFolder(ctx context.Context, root string) (FolderReport, error) {
	return InspectFolderWithProgress(ctx, root, nil)
}

func InspectFolderWithProgress(ctx context.Context, root string, onProgress func(ScanProgress)) (FolderReport, error) {
	start := time.Now()
	cleaned, err := filepath.Abs(root)
	if err != nil {
		return FolderReport{}, err
	}
	st, err := os.Lstat(cleaned)
	if err != nil {
		return FolderReport{}, err
	}
	if !st.IsDir() || isReparsePoint(cleaned, st) {
		return FolderReport{}, errors.New("select a normal folder, not a link or reparse point")
	}
	r := FolderReport{Root: cleaned}
	nodes := []scanDir{{path: cleaned, parent: -1}}
	stack := []int{0}
	var directFiles []FolderSize
	var biggest fileMinHeap
	heap.Init(&biggest)
	var scanErr error
	lastUpdate := time.Now()
	seenEntries := 0
	emitProgress := func(force bool) {
		if onProgress == nil {
			return
		}
		if !force && time.Since(lastUpdate) < 350*time.Millisecond {
			return
		}
		onProgress(ScanProgress{Files: r.Files, Directories: uint64(len(nodes)), Bytes: r.Total, Skipped: r.Skipped})
		lastUpdate = time.Now()
	}
scanLoop:
	for len(stack) > 0 {
		if err := ctx.Err(); err != nil {
			scanErr = err
			break
		}
		if len(nodes) >= maxScanDirs || r.Files >= maxScanFiles {
			r.Truncated = true
			break
		}
		k := len(stack) - 1
		id := stack[k]
		stack = stack[:k]
		entries, readErr := os.ReadDir(nodes[id].path)
		if readErr != nil {
			r.Skipped++
			emitProgress(false)
			continue
		}
		for _, ent := range entries {
			seenEntries++
			if seenEntries%64 == 0 {
				if err := ctx.Err(); err != nil {
					scanErr = err
					break scanLoop
				}
				emitProgress(false)
			}
			if r.Files >= maxScanFiles || len(nodes) >= maxScanDirs {
				r.Truncated = true
				break scanLoop
			}
			path := filepath.Join(nodes[id].path, ent.Name())
			info, statErr := os.Lstat(path)
			if statErr != nil {
				r.Skipped++
				continue
			}
			if info.Mode()&os.ModeSymlink != 0 || (info.IsDir() && isReparsePoint(path, info)) {
				r.Skipped++
				continue
			}
			if info.IsDir() {
				newID := len(nodes)
				nodes = append(nodes, scanDir{path: path, parent: id})
				stack = append(stack, newID)
				continue
			}
			if !info.Mode().IsRegular() {
				r.Skipped++
				continue
			}
			size := info.Size()
			if size < 0 {
				continue
			}
			n := uint64(size)
			r.Total += n
			r.Files++
			nodes[id].bytes += n
			nodes[id].files++
			if id == 0 {
				directFiles = append(directFiles, FolderSize{Name: ent.Name(), Path: path, Bytes: n, Files: 1})
			}
			if n > 0 {
				f := FileSize{Name: ent.Name(), Path: path, Bytes: n}
				if biggest.Len() < topResultCount {
					heap.Push(&biggest, f)
				} else if n > biggest[0].Bytes {
					biggest[0] = f
					heap.Fix(&biggest, 0)
				}
			}
		}
	}
	// A parent was always created before its children; this reverse pass
	// computes recursive totals in linear time without re-reading any files.
	for id := len(nodes) - 1; id > 0; id-- {
		p := nodes[id].parent
		nodes[p].bytes += nodes[id].bytes
		nodes[p].files += nodes[id].files
	}
	// Root files and immediate root directories share the overview list.
	r.Folders = append(r.Folders, directFiles...)
	for id := 1; id < len(nodes); id++ {
		d := nodes[id]
		f := FolderSize{Name: filepath.Base(d.path), Path: d.path, Bytes: d.bytes, Files: d.files}
		if d.parent == 0 {
			r.Folders = append(r.Folders, f)
		}
		if d.bytes > 0 {
			r.LargestFolders = append(r.LargestFolders, f)
		}
	}
	sort.Slice(r.Folders, func(i, j int) bool {
		if r.Folders[i].Bytes == r.Folders[j].Bytes {
			return r.Folders[i].Name < r.Folders[j].Name
		}
		return r.Folders[i].Bytes > r.Folders[j].Bytes
	})
	sort.Slice(r.LargestFolders, func(i, j int) bool {
		if r.LargestFolders[i].Bytes == r.LargestFolders[j].Bytes {
			return r.LargestFolders[i].Path < r.LargestFolders[j].Path
		}
		return r.LargestFolders[i].Bytes > r.LargestFolders[j].Bytes
	})
	if len(r.LargestFolders) > topResultCount {
		r.LargestFolders = r.LargestFolders[:topResultCount]
	}
	r.LargestFiles = append(r.LargestFiles, biggest...)
	sort.Slice(r.LargestFiles, func(i, j int) bool {
		if r.LargestFiles[i].Bytes == r.LargestFiles[j].Bytes {
			return r.LargestFiles[i].Path < r.LargestFiles[j].Path
		}
		return r.LargestFiles[i].Bytes > r.LargestFiles[j].Bytes
	})
	r.Duration = time.Since(start)
	emitProgress(true)
	return r, scanErr
}
