# Contributing to SysSift

SysSift's priority is **accurate, understandable, low-risk PC diagnostics**.

## Issues
Please provide your Windows version/build, what you clicked, what you expected, and what happened. A screenshot helps. Avoid posting IP addresses, usernames, or your private folder paths in public issues.

## Pull requests
1. Keep dependencies minimal and preserve the standalone EXE build.
2. Add tests for new measurement logic or changes to the folder scanner.
3. Explain limits and avoid implying that a single metric proves an issue.
4. Never delete files, change settings, or send network traffic without an explicit user action and clear disclosure.
5. Test `go test ./...` on non-Windows hosts and `go test -vet=off ./...` on Windows; cross-build with the command from README.

## Naming
The brand is **SysSift**, the portable app is `SysSift.exe`, and the repository can be named `syssift`.
