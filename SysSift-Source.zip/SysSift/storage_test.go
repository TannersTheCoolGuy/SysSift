package main

import (
	"context"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestInspectFolder(t *testing.T) {
	d := t.TempDir()
	os.Mkdir(filepath.Join(d, "a"), 0700)
	os.WriteFile(filepath.Join(d, "a", "x.bin"), []byte("abcdef"), 0600)
	os.WriteFile(filepath.Join(d, "z.bin"), []byte("123"), 0600)
	r, e := InspectFolder(context.Background(), d)
	if e != nil {
		t.Fatal(e)
	}
	if r.Total != 9 || r.Files != 2 || len(r.Folders) != 2 || r.Folders[0].Name != "a" {
		t.Fatalf("bad report %+v", r)
	}
}
func TestInspectFolderRejectFile(t *testing.T) {
	f := filepath.Join(t.TempDir(), "file")
	os.WriteFile(f, []byte("x"), 0600)
	_, e := InspectFolder(context.Background(), f)
	if e == nil {
		t.Fatal("expected error")
	}
}
func TestInspectFolderCancel(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	_, e := InspectFolder(ctx, t.TempDir())
	if e == nil {
		t.Fatal("expected cancel")
	}
}
func TestLinkSkipped(t *testing.T) {
	d := t.TempDir()
	os.WriteFile(filepath.Join(d, "ok"), []byte("a"), 0600)
	target := t.TempDir()
	os.WriteFile(filepath.Join(target, "big"), []byte(strings.Repeat("x", 50)), 0600)
	if err := os.Symlink(target, filepath.Join(d, "jump")); err != nil {
		t.Skip(err)
	}
	r, e := InspectFolder(context.Background(), d)
	if e != nil {
		t.Fatal(e)
	}
	if r.Total != 1 {
		t.Fatalf("followed link: %d", r.Total)
	}
}
func TestThresholds(t *testing.T) {
	s := Snapshot{RAMTotal: 100, RAMAvailable: 8, Drives: []DriveInfo{{"C:\\", 1000, 50}}}
	f := findings(s)
	if len(f) < 2 || f[0].Severity != Warning {
		t.Fatalf("missing warnings %+v", f)
	}
}
func TestFormatting(t *testing.T) {
	if humanBytes(1024) != "1.0 KB" {
		t.Fatal(humanBytes(1024))
	}
	if !strings.Contains(reportText(Snapshot{OS: "Windows"}, NetworkResult{}, FolderReport{}), "SysSift") {
		t.Fatal("report")
	}
}

func TestLargestNestedFoldersAndFiles(t *testing.T) {
	root := t.TempDir()
	deep := filepath.Join(root, "Projects", "Game", "Library")
	if err := os.MkdirAll(deep, 0700); err != nil {
		t.Fatal(err)
	}
	if err := os.MkdirAll(filepath.Join(root, "Documents"), 0700); err != nil {
		t.Fatal(err)
	}
	for name, data := range map[string]string{
		filepath.Join(deep, "huge.cache"):            strings.Repeat("X", 101),
		filepath.Join(root, "Documents", "file.txt"): strings.Repeat("B", 40),
		filepath.Join(root, "tiny.txt"):              "A",
	} {
		if err := os.WriteFile(name, []byte(data), 0600); err != nil {
			t.Fatal(err)
		}
	}
	progressCalled := false
	r, err := InspectFolderWithProgress(context.Background(), root, func(p ScanProgress) { progressCalled = true })
	if err != nil {
		t.Fatal(err)
	}
	if !progressCalled {
		t.Fatal("expected scan progress callback")
	}
	if r.Total != 142 || r.Files != 3 || r.Truncated {
		t.Fatalf("wrong totals: %+v", r)
	}
	if len(r.LargestFiles) != 3 || r.LargestFiles[0].Name != "huge.cache" || r.LargestFiles[0].Bytes != 101 {
		t.Fatalf("largest files incorrect: %+v", r.LargestFiles)
	}
	if len(r.LargestFolders) < 3 || r.LargestFolders[0].Name != "Projects" || r.LargestFolders[0].Bytes != 101 {
		t.Fatalf("largest folders incorrect: %+v", r.LargestFolders)
	}
	seenLibrary := false
	for _, f := range r.LargestFolders {
		if f.Name == "Library" && f.Bytes == 101 {
			seenLibrary = true
		}
	}
	if !seenLibrary {
		t.Fatal("deep folder missing from rankings")
	}
	if len(r.Folders) != 3 || r.Folders[0].Name != "Projects" || r.Folders[0].Bytes != 101 {
		t.Fatalf("incorrect root overview: %+v", r.Folders)
	}
}

func TestPartialScanReturnsResultsWhenCancelled(t *testing.T) {
	root := t.TempDir()
	if err := os.WriteFile(filepath.Join(root, "big.bin"), []byte(strings.Repeat("X", 4096)), 0600); err != nil {
		t.Fatal(err)
	}
	ctx, cancel := context.WithCancel(context.Background())
	count := 0
	r, err := InspectFolderWithProgress(ctx, root, func(p ScanProgress) {
		count++
		if count > 0 {
			cancel()
		}
	})
	// A fast scan may complete before its final progress callback triggers cancellation.
	if err != nil && err != context.Canceled {
		t.Fatal(err)
	}
	if r.Total != 4096 || len(r.LargestFiles) == 0 {
		t.Fatalf("expected accessible partial findings: %+v", r)
	}
}
