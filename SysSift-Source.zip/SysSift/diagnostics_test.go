package main

import (
	"strings"
	"testing"
)

func TestNetworkFindingBothFailed(t *testing.T) {
	fs := combinedFindings(Snapshot{}, NetworkResult{Ran: true})
	if len(fs) != 1 || !strings.Contains(fs[0].Title, "Connection") {
		t.Fatalf("unexpected: %+v", fs)
	}
}
func TestNetworkFailureNotOverstated(t *testing.T) {
	fs := combinedFindings(Snapshot{}, NetworkResult{Ran: true, DNSOK: true})
	if len(fs) != 1 || !strings.Contains(fs[0].Reason, "TCP") {
		t.Fatalf("unexpected: %+v", fs)
	}
}
func TestReportRedactsLocalDetails(t *testing.T) {
	s := Snapshot{Hostname: "VERYPRIVATE_HOST", OS: "Windows 11"}
	n := NetworkResult{Ran: true, LocalIP: "192.168.222.111"}
	f := FolderReport{Root: "C:/Users/veryprivate/folder"}
	txt := reportText(s, n, f)
	for _, secret := range []string{"VERYPRIVATE_HOST", "192.168.222.111", "C:/Users/veryprivate/folder"} {
		if strings.Contains(txt, secret) {
			t.Errorf("found private data %s", secret)
		}
	}
}
func TestNoFalseWarningDefault(t *testing.T) {
	fs := findings(Snapshot{RAMTotal: 100, RAMAvailable: 50, Drives: []DriveInfo{{Name: "C:\\", Total: 1000, Free: 500}}})
	if len(fs) != 1 || fs[0].Severity != Info {
		t.Fatalf("unreasonable warning: %+v", fs)
	}
}
