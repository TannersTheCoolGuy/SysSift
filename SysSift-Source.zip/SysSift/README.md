<p align="center"><img src="assets/logo.png" width="600" alt="SysSift logo" /></p>

<h1 align="center">SysSift</h1>
<p align="center"><strong>Understand your Windows PC. No guessing, no fake optimization.</strong></p>
<p align="center">Free • Portable • Open source • Read-only by default</p>

SysSift is a small, **standalone Windows 10/11 application** that combines useful PC diagnostics in one focused window. It runs without an installer, account, subscription, bundled browser, or Python runtime. Built in Go with native Win32 drawing and system APIs.

> **v0.2.0 beta:** The executable cross-compiles successfully from Linux and the non-UI diagnostics pass automated tests. It has not yet been interactively validated on a Windows machine. Please report UI issues, crashes, or inaccurate results.

## What it does

| Area | Details |
| --- | --- |
| **Overview** | CPU utilization, physical RAM, system drive space, uptime, and explainable findings |
| **Performance** | Live CPU/RAM updates and highest working-set memory processes (when accessible) |
| **Storage** | **Scan C: drive** or a chosen folder; see ranked biggest nested folders and individual files, select a result, open its location in Explorer, and page through the rankings |
| **Network** | Active IPv4 adapter, local address, and optional DNS/TCP connectivity probes |
| **System** | Windows version/build, logical processors, RAM, uptime and concise threshold checks |
| **Reports** | Export a local text report with addresses, hostname and scanned folder paths omitted |

The dashboard explains **why something might matter** and offers modest, grounded next steps. A single high CPU reading is not evidence of a broken PC.

### Safe by default

- SysSift **does not clean, optimize, terminate processes, modify the registry, or repair anything automatically**.
- Folder inspection reads metadata only, skips symbolic links and avoids traversing Windows reparse-point directories. Scan limits: up to 1,000,000 files or 175,000 directories. Permissions errors and skipped entries are counted. Results explicitly identify incomplete scans.
- A scan can be cancelled using the button or `Esc`. Counts progress while it runs. Large whole-drive scans may take several minutes or hit the scan limits.
- Network probes only run when you press **Run checks** or **Run network tests**. They resolve `example.com` and try a TCP connection to `1.1.1.1:443`. No background telemetry.
- Reports omit hostname, local IP address and absolute folder paths. Process executable names, Windows version and system measurements are included, so review before sharing.

## Download and run

1. Get `SysSift.exe` from the GitHub Releases page (once a release is published) or build it yourself.
2. Save it anywhere and double-click it. You do **not** need administrator privileges.
3. Use the sidebar for Overview, Performance, Storage, Network and System. On **Storage**, click **Scan C: drive**, or **Browse** to scan a smaller location; when results finish, choose an item and click **Open selected**.
4. Press **Export report** to save a diagnostic summary locally.

Windows SmartScreen may show a warning because the beta is unsigned. **Always download executables only from a source you trust** and verify their checksums. Building from source is an alternative.

## Building from source

Requires Go 1.23 or newer. No third-party Go packages are needed.

**Windows:** Run `BUILD_WINDOWS.bat`, or use:

```powershell
go test -vet=off ./...
go build -trimpath -ldflags="-s -w -H=windowsgui" -o SysSift.exe .
```

**Linux/macOS cross-compile:**

```bash
go test ./...
CGO_ENABLED=0 GOOS=windows GOARCH=amd64 go build -trimpath -ldflags="-s -w -H=windowsgui" -o SysSift.exe .
```

`syssift_amd64.syso` contains the Windows Explorer icon and application manifest. It is already included. To regenerate it after changing `assets/icon.ico`, run `python tools/embed_icon.py` (standard library only).

Some Windows-specific `unsafe.Pointer` conversions bridge native Win32 callbacks/memory. Windows tests run with `-vet=off` because `go vet` flags those intentional conversions; compiler checks and normal unit tests remain enabled.

## Understanding storage results

- **Largest folders** includes folders from any depth beneath the chosen root, not just its immediate children. Ancestor and descendant folder sizes overlap, so do **not** add these rankings together.
- **Largest files** ranks ordinary files by logical file size. Sparse files, file-system metadata, hard links, compression and virtual disks can make these totals differ from actual drive-space usage.
- Some Windows directories are permission-protected and are skipped. Limit-reached and skipped-entry warnings mean the ranking is incomplete. SysSift does not ask for administrator privileges and does not delete anything.
- Use **Next** and **Previous** to see up to the top 60 items in each category. Selecting an item displays its location, and **Open selected** opens the folder or selects the file in Explorer.

## What SysSift does *not* do

This is **not** an antivirus, SMART disk checker, FPS booster, internet speed test, driver updater, or replacement for Task Manager. Network test failures may be caused by VPNs and firewalls, and inaccessible process information is omitted. Not all Windows issues can be detected from a lightweight snapshot.

## Roadmap

- [ ] Validate layouts and folder/network workflows on Windows 10 and 11
- [ ] Add an accessible native control layer and proper keyboard navigation
- [ ] Better startup-app impact summaries, clearly distinguishing correlation from causation
- [ ] More targeted troubleshooting guides based on confirmed measurements
- [ ] Signed releases if sustainable

## Contributing

Bug reports with reproduction steps are particularly valuable. See [CONTRIBUTING.md](CONTRIBUTING.md) and [SECURITY.md](SECURITY.md).

MIT licensed. See [LICENSE](LICENSE).
