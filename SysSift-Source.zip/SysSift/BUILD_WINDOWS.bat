@echo off
setlocal
where go >nul 2>nul
if errorlevel 1 (
    echo Go 1.23 or later is required to build from source.
    pause
    exit /b 1
)
go test -vet=off ./...
if errorlevel 1 (
    echo Tests failed. No executable was built.
    pause
    exit /b 1
)
set CGO_ENABLED=0
set GOOS=windows
set GOARCH=amd64
go build -trimpath -ldflags="-s -w -H=windowsgui" -o SysSift.exe .
if errorlevel 1 (
    echo Build failed.
    pause
    exit /b 1
)
echo Success: SysSift.exe is ready.
pause
