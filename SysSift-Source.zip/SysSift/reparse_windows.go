//go:build windows

package main

import "os"
import "syscall"

func isReparsePoint(path string, info os.FileInfo) bool {
	if info.Mode()&os.ModeSymlink != 0 {
		return true
	}
	p, e := syscall.UTF16PtrFromString(path)
	if e != nil {
		return true
	}
	attrs, e := syscall.GetFileAttributes(p)
	if e != nil {
		return true
	}
	return attrs&syscall.FILE_ATTRIBUTE_REPARSE_POINT != 0
}
