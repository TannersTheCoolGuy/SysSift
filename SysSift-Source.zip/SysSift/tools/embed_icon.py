#!/usr/bin/env python3
"""Build a Go-compatible Windows .syso COFF icon/manifest resource.
Uses only Python's standard library. Source image data comes from assets/icon.ico.
"""
import struct
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
ICO=ROOT/'assets/icon.ico'
OUT=ROOT/'syssift_amd64.syso'

def align(buffer, n=4):
    while len(buffer)%n: buffer.append(0)

def extract_ico(p):
    raw=p.read_bytes()
    reserved, typ, num=struct.unpack_from('<HHH',raw)
    if reserved!=0 or typ!=1 or num==0: raise ValueError('Invalid ICO')
    out=[]
    for i in range(num):
        w,h,colors,zero,planes,bpp,size,offset=struct.unpack_from('<BBBBHHII',raw,6+16*i)
        blob=raw[offset:offset+size]
        if len(blob)!=size: raise ValueError('Incomplete ICO entry')
        out.append((w,h,colors,zero,planes,bpp,blob))
    return out

def build():
    icons=extract_ico(ICO)
    # Resource directories use section-relative offsets; leaves refer to .rsrc via relocations.
    # RT_ICON = 3, RT_GROUP_ICON = 14, RT_MANIFEST = 24
    manifest='''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<assembly xmlns="urn:schemas-microsoft-com:asm.v1" manifestVersion="1.0">
  <assemblyIdentity version="1.0.0.0" processorArchitecture="amd64" name="SysSift" type="win32"/>
  <description>SysSift PC diagnostics</description>
  <trustInfo xmlns="urn:schemas-microsoft-com:asm.v3"><security><requestedPrivileges><requestedExecutionLevel level="asInvoker" uiAccess="false"/></requestedPrivileges></security></trustInfo>
  <compatibility xmlns="urn:schemas-microsoft-com:compatibility.v1"><application><supportedOS Id="{8e0f7a12-bfb3-4fe8-b9a5-48fd50a15a9a}"/></application></compatibility>
</assembly>'''.encode('utf-8')
    entries=[]
    for i,(w,h,colors,zero,planes,bpp,blob) in enumerate(icons,1):entries.append((3,i,blob))
    group=bytearray(struct.pack('<HHH',0,1,len(icons)))
    for i,(w,h,colors,zero,planes,bpp,blob) in enumerate(icons,1):
        group+=struct.pack('<BBBBHHIH',w,h,colors,zero,planes,bpp,len(blob),i)
    entries.extend([(14,1,bytes(group)),(24,1,manifest)])
    # Tree, each Type -> ID -> language 0x409 -> leaf.
    buf=bytearray()
    relocs=[]
    def reserve(n):
        at=len(buf);buf.extend(b'\0'*n);return at
    def dir_head(n):
        at=reserve(16+n*8);struct.pack_into('<IIHHHH',buf,at,0,0,0,0,0,n);return at
    types=sorted({typ for typ,_,_ in entries})
    root=dir_head(len(types))
    data_entries=[]
    for ti,typ in enumerate(types):
        subset=[e for e in entries if e[0]==typ]
        dt=dir_head(len(subset))
        struct.pack_into('<II',buf,root+16+ti*8,typ,0x80000000|dt)
        for j,(tp,identifier,blob) in enumerate(subset):
            dlang=dir_head(1)
            struct.pack_into('<II',buf,dt+16+j*8,identifier,0x80000000|dlang)
            leaf=reserve(16)
            struct.pack_into('<II',buf,dlang+16,0x409,leaf)
            data_entries.append((leaf,blob))
    for leaf,blob in data_entries:
        align(buf,4)
        at=len(buf);buf.extend(blob)
        struct.pack_into('<IIII',buf,leaf,at,len(blob),0,0)
        relocs.append(leaf)
    align(buf,4)
    # COFF 64-bit object with a .rsrc section and ADDR32NB relocations at each RVA.
    coff_header_size=20
    section_header_size=40
    raw_offset=coff_header_size+section_header_size
    reloc_offset=raw_offset+len(buf)
    symbol_offset=reloc_offset+10*len(relocs)
    coff=bytearray()
    coff+=struct.pack('<HHIIIHH',0x8664,1,0,symbol_offset,1,0,0)
    coff+=struct.pack('<8sIIIIIIHHI',b'.rsrc\0\0\0',0,0,len(buf),raw_offset,reloc_offset,0,len(relocs),0,0x40000040)
    coff+=buf
    for ra in relocs: coff+=struct.pack('<IIH',ra,0,3)
    coff+=struct.pack('<8sIhHBB',b'.rsrc\0\0\0',0,1,0,3,0)
    coff+=struct.pack('<I',4)
    OUT.write_bytes(coff)
    print('Created',OUT,'(' ,len(coff),'bytes,',len(icons),'icons)')
if __name__=='__main__': build()
