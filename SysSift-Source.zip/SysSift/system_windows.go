//go:build windows

package main

import (
	"os"
	"runtime"
	"sort"
	"strconv"
	"syscall"
	"time"
	"unsafe"
)

var sysKernel = syscall.NewLazyDLL("kernel32.dll")
var sysPsapi = syscall.NewLazyDLL("psapi.dll")
var sysNtdll = syscall.NewLazyDLL("ntdll.dll")
var pGetSystemTimes = sysKernel.NewProc("GetSystemTimes")
var pGlobalMemoryStatusEx = sysKernel.NewProc("GlobalMemoryStatusEx")
var pGetLogicalDrives = sysKernel.NewProc("GetLogicalDrives")
var pGetDiskFreeSpaceEx = sysKernel.NewProc("GetDiskFreeSpaceExW")
var pGetDriveType = sysKernel.NewProc("GetDriveTypeW")
var pGetSystemPowerStatus = sysKernel.NewProc("GetSystemPowerStatus")
var pOpenProcess = sysKernel.NewProc("OpenProcess")
var pGetProcessMemoryInfo = sysPsapi.NewProc("GetProcessMemoryInfo")
var pRtlGetVersion = sysNtdll.NewProc("RtlGetVersion")
var pGetTickCount64 = sysKernel.NewProc("GetTickCount64")

type memStatus struct {
	Length, MemoryLoad                                                                    uint32
	TotalPhys, AvailPhys, TotalPage, AvailPage, TotalVirtual, AvailVirtual, AvailExtended uint64
}
type systemPowerStatus struct {
	ACLineStatus, BatteryFlag, BatteryLifePercent, SystemStatusFlag byte
	BatteryLifeTime, BatteryFullLifeTime                            uint32
}
type procMem struct {
	Cb, PageFault                                                                                                                         uint32
	PeakWorkingSet, WorkingSet, QuotaPeakPagedPool, QuotaPagedPool, QuotaPeakNonPagedPool, QuotaNonPagedPool, PagefileUsage, PeakPagefile uintptr
}
type windowsVersion struct {
	Size, Major, Minor, Build, Platform   uint32
	CSD                                   [128]uint16
	ServiceMajor, ServiceMinor, SuiteMask uint16
	ProductType, Reserved                 byte
}
type cpuSampler struct {
	idle, kernel, user uint64
	seen               bool
}

func ftValue(f syscall.Filetime) uint64 { return uint64(f.HighDateTime)<<32 | uint64(f.LowDateTime) }
func (p *cpuSampler) sample() float64 {
	var idle, kernel, user syscall.Filetime
	ok, _, _ := pGetSystemTimes.Call(uintptr(unsafe.Pointer(&idle)), uintptr(unsafe.Pointer(&kernel)), uintptr(unsafe.Pointer(&user)))
	if ok == 0 {
		return 0
	}
	i, k, u := ftValue(idle), ftValue(kernel), ftValue(user)
	if !p.seen {
		p.idle, p.kernel, p.user, p.seen = i, k, u, true
		return 0
	}
	dk, du, di := k-p.kernel, u-p.user, i-p.idle
	p.idle, p.kernel, p.user = i, k, u
	total := dk + du
	if total == 0 || di > total {
		return 0
	}
	return clampPct(100 * float64(total-di) / float64(total))
}
func osVersion() string {
	v := windowsVersion{Size: uint32(unsafe.Sizeof(windowsVersion{}))}
	r, _, _ := pRtlGetVersion.Call(uintptr(unsafe.Pointer(&v)))
	if r != 0 {
		return "Windows 10 or later"
	}
	if v.Build >= 22000 {
		return "Windows 11 (build " + itoa(int(v.Build)) + ")"
	}
	return "Windows 10 (build " + itoa(int(v.Build)) + ")"
}
func driveInfo() []DriveInfo {
	mask, _, _ := pGetLogicalDrives.Call()
	arr := []DriveInfo{}
	for i := 0; i < 26; i++ {
		if mask&(1<<uint(i)) == 0 {
			continue
		}
		name := string(rune('A'+i)) + ":\\"
		up, _ := syscall.UTF16PtrFromString(name)
		typ, _, _ := pGetDriveType.Call(uintptr(unsafe.Pointer(up)))
		if typ != 2 && typ != 3 {
			continue
		}
		var avail, total, free uint64
		ok, _, _ := pGetDiskFreeSpaceEx.Call(uintptr(unsafe.Pointer(up)), uintptr(unsafe.Pointer(&avail)), uintptr(unsafe.Pointer(&total)), uintptr(unsafe.Pointer(&free)))
		if ok != 0 && total > 0 {
			arr = append(arr, DriveInfo{Name: name, Total: total, Free: avail})
		}
	}
	return arr
}
func powerInfo() PowerInfo {
	var p systemPowerStatus
	ok, _, _ := pGetSystemPowerStatus.Call(uintptr(unsafe.Pointer(&p)))
	if ok == 0 || p.BatteryFlag&128 != 0 || p.BatteryLifePercent == 255 {
		return PowerInfo{}
	}
	return PowerInfo{HasBattery: true, Plugged: p.ACLineStatus == 1, Percent: int(p.BatteryLifePercent)}
}
func processesTop() []ProcessInfo {
	h, e := syscall.CreateToolhelp32Snapshot(syscall.TH32CS_SNAPPROCESS, 0)
	if e != nil {
		return nil
	}
	defer syscall.CloseHandle(h)
	var ent syscall.ProcessEntry32
	ent.Size = uint32(unsafe.Sizeof(ent))
	if e = syscall.Process32First(h, &ent); e != nil {
		return nil
	}
	out := make([]ProcessInfo, 0, 150)
	for count := 0; count < 1200; count++ {
		name := syscall.UTF16ToString(ent.ExeFile[:])
		if name == "" {
			name = "System process"
		}
		if ent.ProcessID > 0 {
			ph, _, _ := pOpenProcess.Call(0x1000|0x0010, 0, uintptr(ent.ProcessID))
			if ph != 0 {
				var pm procMem
				pm.Cb = uint32(unsafe.Sizeof(pm))
				ok, _, _ := pGetProcessMemoryInfo.Call(ph, uintptr(unsafe.Pointer(&pm)), uintptr(pm.Cb))
				if ok != 0 {
					out = append(out, ProcessInfo{Name: name, PID: ent.ProcessID, Memory: uint64(pm.WorkingSet)})
				}
				syscall.CloseHandle(syscall.Handle(ph))
			}
		}
		if syscall.Process32Next(h, &ent) != nil {
			break
		}
	}
	sort.Slice(out, func(i, j int) bool { return out[i].Memory > out[j].Memory })
	if len(out) > 11 {
		return out[:11]
	}
	return out
}
func basicSnapshot(p *cpuSampler, withProcesses bool) Snapshot {
	s := Snapshot{Updated: time.Now(), CPU: p.sample(), OS: osVersion(), CPUs: runtime.NumCPU(), Power: powerInfo(), Drives: driveInfo()}
	s.Hostname, _ = os.Hostname()
	r, _, _ := pGetTickCount64.Call()
	s.Uptime = time.Duration(r) * time.Millisecond
	ms := memStatus{Length: uint32(unsafe.Sizeof(memStatus{}))}
	ok, _, _ := pGlobalMemoryStatusEx.Call(uintptr(unsafe.Pointer(&ms)))
	if ok != 0 {
		s.RAMTotal, s.RAMAvailable = ms.TotalPhys, ms.AvailPhys
	}
	if withProcesses {
		s.Processes = processesTop()
	}
	return s
}
func itoa(n int) string { return strconv.Itoa(n) }
