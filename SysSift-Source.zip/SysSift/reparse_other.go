//go:build !windows

package main

import "os"

func isReparsePoint(path string, info os.FileInfo) bool { return info.Mode()&os.ModeSymlink != 0 }
