package main

import (
	"fmt"
	"math"
	"sort"
	"strings"
	"time"
)

type Severity int

const (
	Info Severity = iota
	Warning
	Critical
)

type Finding struct {
	Severity              Severity
	Title, Reason, Advice string
}
type ProcessInfo struct {
	Name   string
	PID    uint32
	Memory uint64
}
type DriveInfo struct {
	Name        string
	Total, Free uint64
}
type PowerInfo struct {
	HasBattery, Plugged bool
	Percent             int
}
type Snapshot struct {
	Updated                time.Time
	CPU                    float64
	RAMTotal, RAMAvailable uint64
	Drives                 []DriveInfo
	Processes              []ProcessInfo
	Uptime                 time.Duration
	OS, Hostname           string
	CPUs                   int
	Power                  PowerInfo
	Err                    string
}

func (s Snapshot) PrimaryDisk() (DriveInfo, bool) {
	for _, d := range s.Drives {
		if strings.EqualFold(d.Name, "C:\\") {
			return d, true
		}
	}
	if len(s.Drives) > 0 {
		return s.Drives[0], true
	}
	return DriveInfo{}, false
}
func (s Snapshot) RAMUsedPercent() float64 {
	if s.RAMTotal == 0 {
		return 0
	}
	return 100 * float64(s.RAMTotal-s.RAMAvailable) / float64(s.RAMTotal)
}
func diskUsedPercent(d DriveInfo) float64 {
	if d.Total == 0 {
		return 0
	}
	return 100 * float64(d.Total-d.Free) / float64(d.Total)
}
func clampPct(x float64) float64 {
	if math.IsNaN(x) || math.IsInf(x, 0) || x < 0 {
		return 0
	}
	if x > 100 {
		return 100
	}
	return x
}
func humanBytes(n uint64) string {
	if n < 1024 {
		return fmt.Sprintf("%d B", n)
	}
	units := []string{"KB", "MB", "GB", "TB", "PB"}
	v := float64(n) / 1024.0
	for i, u := range units {
		if v < 1024 || i == len(units)-1 {
			return fmt.Sprintf("%.1f %s", v, u)
		}
		v /= 1024
	}
	return "0 B"
}
func findings(s Snapshot) []Finding {
	out := []Finding{}
	if s.RAMTotal > 0 {
		ram := s.RAMUsedPercent()
		if ram >= 90 {
			out = append(out, Finding{Warning, "Memory pressure is high", fmt.Sprintf("%.0f%% of physical RAM is in use.", ram), "Review memory-hungry apps on the Performance tab. Close only apps you recognize and no longer need."})
		} else if ram >= 80 {
			out = append(out, Finding{Info, "Memory use is elevated", fmt.Sprintf("%.0f%% of physical RAM is in use.", ram), "Monitor for slowdowns; check top applications before making changes."})
		}
	}
	if s.CPU >= 90 {
		out = append(out, Finding{Warning, "CPU is heavily loaded", fmt.Sprintf("CPU utilization was %.0f%% at the last sample.", s.CPU), "Watch whether usage stays high; brief spikes during games or updates are normal."})
	}
	for _, d := range s.Drives {
		if d.Total == 0 {
			continue
		}
		pct := 100 * float64(d.Free) / float64(d.Total)
		if pct < 10 {
			out = append(out, Finding{Warning, fmt.Sprintf("Low space on %s", d.Name), fmt.Sprintf("Only %s free (%.0f%%).", humanBytes(d.Free), pct), "Inspect large personal folders and installed apps. Avoid deleting unknown system files."})
		} else if pct < 18 {
			out = append(out, Finding{Info, fmt.Sprintf("Storage getting tight on %s", d.Name), fmt.Sprintf("%s free (%.0f%%).", humanBytes(d.Free), pct), "Keep some free space for updates, downloads and temporary files."})
		}
	}
	if s.Power.HasBattery && !s.Power.Plugged && s.Power.Percent >= 0 && s.Power.Percent < 15 {
		out = append(out, Finding{Warning, "Battery is low", fmt.Sprintf("Battery charge is %d%% and power is unplugged.", s.Power.Percent), "Connect the charger to avoid an unexpected shutdown."})
	}
	if len(out) == 0 {
		out = append(out, Finding{Info, "No threshold alerts right now", "Current CPU, memory and accessible disk measurements did not cross SysSift's warning thresholds.", "This is not a comprehensive hardware or malware scan. Use the other tabs for more detail."})
	}
	sort.SliceStable(out, func(i, j int) bool { return out[i].Severity > out[j].Severity })
	return out
}

// combinedFindings adds user-triggered network results to the basic local checks.
// A failed probe is not a diagnosis by itself; filtering, VPNs and firewall rules are common causes.
func combinedFindings(s Snapshot, n NetworkResult) []Finding {
	items := findings(s)
	if !n.Ran || (n.DNSOK && n.TCPOK) {
		return items
	}
	if len(items) == 1 && items[0].Title == "No threshold alerts right now" {
		items = nil
	}
	switch {
	case !n.DNSOK && !n.TCPOK:
		items = append(items, Finding{Warning, "Connection checks failed", "The optional DNS lookup and outbound TCP test both failed.", "Check Wi-Fi or Ethernet, then review any VPN, proxy or firewall settings. A blocked test does not prove the whole internet is offline."})
	case !n.DNSOK:
		items = append(items, Finding{Warning, "DNS lookup was unsuccessful", "The test domain could not be resolved, but the TCP endpoint was reachable.", "Check your configured DNS provider or VPN filtering. Some networks intentionally block external test domains."})
	default:
		items = append(items, Finding{Info, "TCP probe could not connect", "The test domain resolved, but the TCP endpoint was not reachable.", "Check whether the network blocks 1.1.1.1:443. This does not automatically mean your internet is down."})
	}
	sort.SliceStable(items, func(i, j int) bool { return items[i].Severity > items[j].Severity })
	return items
}
func reportText(s Snapshot, n NetworkResult, f FolderReport) string {
	var b strings.Builder
	fmt.Fprintf(&b, "SysSift diagnostic report\nGenerated: %s\nPrivacy: read-only. Local addresses and folder paths omitted.\n\n", time.Now().Format(time.RFC3339))
	fmt.Fprintf(&b, "SYSTEM\nOS: %s\nLogical CPU cores: %d\nUptime: %s\nCPU usage (sample): %.1f%%\nRAM: %s used of %s (%.1f%%)\n", s.OS, s.CPUs, s.Uptime.Truncate(time.Minute), s.CPU, humanBytes(s.RAMTotal-s.RAMAvailable), humanBytes(s.RAMTotal), s.RAMUsedPercent())
	for _, d := range s.Drives {
		fmt.Fprintf(&b, "Drive %s: %s free of %s\n", d.Name, humanBytes(d.Free), humanBytes(d.Total))
	}
	b.WriteString("\nFINDINGS\n")
	for _, x := range combinedFindings(s, n) {
		fmt.Fprintf(&b, "- %s: %s Advice: %s\n", x.Title, x.Reason, x.Advice)
	}
	b.WriteString("\nTOP MEMORY PROCESSES\n")
	for i, p := range s.Processes {
		if i == 8 {
			break
		}
		fmt.Fprintf(&b, "- %s: %s\n", p.Name, humanBytes(p.Memory))
	}
	b.WriteString("\nNETWORK TEST (user-initiated)\n")
	if !n.Ran {
		b.WriteString("Not run.\n")
	} else {
		fmt.Fprintf(&b, "DNS resolution: %s (%d ms)\nTCP reachability: %s (%d ms)\nNote: tests use example.com and 1.1.1.1:443; these are not speed tests.\n", checkLabel(n.DNSOK), n.DNSMillis, checkLabel(n.TCPOK), n.TCPMillis)
	}
	b.WriteString("\nFOLDER INSPECTION\n")
	if f.Root == "" {
		b.WriteString("Not run.\n")
	} else {
		fmt.Fprintf(&b, "Scanned items: %d files; total %s; accessible directories only; skipped entries: %d\n", f.Files, humanBytes(f.Total), f.Skipped)
		if f.Truncated {
			b.WriteString("Inspection was limited; totals may be incomplete.\n")
		}
	}
	b.WriteString("\nThis report does not diagnose hardware failures or guarantee system safety.\n")
	return b.String()
}
func checkLabel(v bool) string {
	if v {
		return "Succeeded"
	}
	return "Failed"
}
