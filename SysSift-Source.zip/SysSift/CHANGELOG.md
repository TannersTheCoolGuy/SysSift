# Changelog

## v0.2.0 (2026-11-14)

- Added a one-click **Scan C: drive** action on the Storage page.
- Added ranked **largest folders** (including nested directories) and **largest individual files**.
- Added live file/byte counts, scan-cancellation feedback and incomplete-results warnings.
- Added selection, full path preview, Explorer reveal, and Next/Previous results pagination.
- Reorganized the Storage page to prioritize rankings over the drive capacity summary.
- Increased traversal limits to 1,000,000 files / 175,000 directories and added test coverage for nested totals and file ranking.
- Kept all storage operations read-only.

## v0.1.1 (2026-11-14)

- Switched to a brighter blue-and-white interface.
- Made **Run checks** show progress/status feedback and return to Overview.

## v0.1.0 (2026-11-14)

- First portable native Windows beta.
- Five-page dark desktop interface with branded SysSift icon.
- Live CPU and RAM monitoring, local drive usage, system uptime and process memory ranking.
- Cancellable, read-only folder-size scanner with symlink/reparse-point avoidance and traversal limits.
- User-initiated DNS and TCP reachability tests with transparent endpoints.
- Rule-based findings with recommendations and limits; no fabricated health score.
- Local text report export with path/IP/hostname redaction.
- MIT source license, unit tests and GitHub Actions build workflow.

**Known limitation:** GUI not yet manually tested on Windows. Treat this as an early beta.
