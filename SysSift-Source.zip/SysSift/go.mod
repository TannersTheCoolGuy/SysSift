module github.com/syssift/syssift

go 1.23
