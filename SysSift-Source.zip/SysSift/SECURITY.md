# Security and privacy

SysSift scans local system metrics and folders with the same permissions as the user who runs it. It needs no administrator elevation and does not change PC settings.

A folder scan is bounded, cancellable, and configured not to follow symbolic links or Windows reparse points. Windows junctions and other reparse points are skipped. Symlink-related race conditions may still exist if another process changes the filesystem during scanning; do not use it as a security boundary.

The network page initiates requests to example.com and 1.1.1.1:443 **only on user command**. There is no telemetry, automatic updating or account login.

The text report deliberately omits IPs, hostnames, and absolute filesystem paths. It does include process names and usage measurements. Review files before posting them publicly.

To report a suspected security issue, open a private security advisory in your GitHub repository after enabling GitHub's private vulnerability reporting. Do not publish exploit details before a fix is available.
